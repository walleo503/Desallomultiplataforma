using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;

namespace GestionHotelera.Data
{
    public class PermissionClaimsTransformation : IClaimsTransformation
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<IdentityUser> _userManager;

        public PermissionClaimsTransformation(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var identity = principal.Identity as ClaimsIdentity;
            if (identity == null || !identity.IsAuthenticated) return principal;
            if (identity.HasClaim(c => c.Type == "PermisosCargados")) return principal;

            // El estado laboral se consulta desde Identity en cada request. Así una cuenta
            // suspendida/despedida deja de recibir permisos aunque conserve una cookie previa.
            var usuario = await _userManager.GetUserAsync(principal);
            if (usuario != null)
            {
                var estado = (await _userManager.GetClaimsAsync(usuario))
                    .FirstOrDefault(c => c.Type == "EstadoEmpleado")?.Value;
                if (string.Equals(estado, "Suspendido", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(estado, "Despedido", StringComparison.OrdinalIgnoreCase))
                {
                    identity.AddClaim(new Claim("PermisosCargados", "true"));
                    identity.AddClaim(new Claim("EmpleadoInactivo", estado));
                    return principal;
                }
            }

            var nombresDeRoles = identity.FindAll(ClaimTypes.Role)
                .Select(c => c.Value)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
            var permisosYaAgregados = new HashSet<string>();

            foreach (var nombreRol in nombresDeRoles)
            {
                var rol = await _roleManager.FindByNameAsync(nombreRol);
                if (rol == null) continue;
                var claimsDelRol = await _roleManager.GetClaimsAsync(rol);
                foreach (var claim in claimsDelRol.Where(c => c.Type == "Permission"))
                {
                    if (permisosYaAgregados.Add(claim.Value))
                        identity.AddClaim(new Claim("Permission", claim.Value));
                }
            }

            identity.AddClaim(new Claim("PermisosCargados", "true"));
            return principal;
        }
    }
}
