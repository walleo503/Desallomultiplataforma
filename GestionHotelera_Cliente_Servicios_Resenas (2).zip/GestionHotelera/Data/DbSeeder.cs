using System.Security.Claims;
using GestionHotelera.Models.Authorization;
using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace GestionHotelera.Data
{
    // Se ejecuta después de aplicar las migraciones. Es idempotente:
    // conserva habitaciones, usuarios, cargos y turnos existentes.
    public static class DbSeeder
    {
        public const string RolAdministrador = "Administrador";
        public const string RolSecretario = "Secretario";
        public const string RolCliente = "Cliente";

        public static async Task SeedAsync(IServiceProvider services)
        {
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = services.GetRequiredService<UserManager<IdentityUser>>();
            var context = services.GetRequiredService<ApplicationDbContext>();

            // Si ya existía algún rol, este hotel ya pasó por la inicialización.
            // No volver a crear habitaciones que se borraron deliberadamente.
            var instalacionNueva = !await roleManager.RoleExistsAsync(RolAdministrador)
                && !await roleManager.RoleExistsAsync(RolSecretario)
                && !await roleManager.RoleExistsAsync(RolCliente);

            foreach (var nombre in new[] { RolAdministrador, RolSecretario, RolCliente })
            {
                if (await roleManager.RoleExistsAsync(nombre)) continue;
                var result = await roleManager.CreateAsync(new IdentityRole(nombre));
                VerificarResultado(result, $"crear el rol {nombre}");
            }

            await AsignarPermisosARolAsync(roleManager, RolAdministrador, new[]
            {
                Permisos.EmpleadosVer, Permisos.EmpleadosCrear, Permisos.EmpleadosEditar, Permisos.EmpleadosEliminar,
                Permisos.HabitacionesVer, Permisos.HabitacionesCrear, Permisos.HabitacionesEditar,
                Permisos.HabitacionesEliminar, Permisos.HabitacionesCambiarEstado,
                Permisos.ReservasVerTodas, Permisos.ReservasCrear, Permisos.ReservasCheckIn, Permisos.ReservasCheckOut,
                Permisos.SolicitudesGestionar, Permisos.PagosRegistrar, Permisos.ReportesVerIngresos
            });

            await AsignarPermisosARolAsync(roleManager, RolSecretario, new[]
            {
                Permisos.HabitacionesVer, Permisos.HabitacionesCambiarEstado,
                Permisos.ReservasVerTodas, Permisos.ReservasCrear, Permisos.ReservasCheckIn, Permisos.ReservasCheckOut,
                Permisos.SolicitudesGestionar, Permisos.PagosRegistrar
            });

            await AsignarPermisosARolAsync(roleManager, RolCliente, new[]
            {
                Permisos.ReservasVerPropias, Permisos.ReservasCrear,
                Permisos.ReservasCancelar, Permisos.ReservasExtender,
                Permisos.SolicitudesCrear, Permisos.SolicitudesVerPropias, Permisos.ResenasCrear
            });

            // En versiones anteriores el Cliente recibía Habitaciones.Ver,
            // que abre la tabla interna de administración. El catálogo es público.
            var rolCliente = await roleManager.FindByNameAsync(RolCliente)
                ?? throw new InvalidOperationException("No existe el rol Cliente.");
            foreach (var permiso in (await roleManager.GetClaimsAsync(rolCliente))
                .Where(c => c.Type == "Permission" && c.Value == Permisos.HabitacionesVer))
            {
                VerificarResultado(await roleManager.RemoveClaimAsync(rolCliente, permiso),
                    "retirar el permiso interno de habitaciones al Cliente");
            }

            var cargoAdministradorId = await ObtenerOCrearCargoAsync(context, "Administrador");
            var cargoSecretarioId = await ObtenerOCrearCargoAsync(context, "Secretario");
            var horarioMananaId = await ObtenerOCrearHorarioAsync(context, "Mañana", "6:00 a. m. - 12:00 p. m.");
            await ObtenerOCrearHorarioAsync(context, "Tarde", "12:00 p. m. - 6:00 p. m.");
            await ObtenerOCrearHorarioAsync(context, "Noche", "6:00 p. m. - 6:00 a. m.");

            if (instalacionNueva && !await context.Habitaciones.AnyAsync())
            {
                context.Habitaciones.AddRange(
                    new Habitacion { Numero = "101", Tipo = "Sencilla", Capacidad = 2, NumeroCamas = 1, Piso = 1, Precio = 45.00m, Descripcion = "Habitación sencilla, ideal para viajeros individuales. Incluye cama matrimonial, escritorio y baño privado.", Estado = EstadoHabitacion.Disponible },
                    new Habitacion { Numero = "102", Tipo = "Doble", Capacidad = 4, NumeroCamas = 2, Piso = 1, Precio = 65.00m, Descripcion = "Habitación doble con dos camas individuales, perfecta para familias pequeñas o grupos de amigos.", Estado = EstadoHabitacion.Disponible },
                    new Habitacion { Numero = "103", Tipo = "Doble", Capacidad = 4, NumeroCamas = 2, Piso = 1, Precio = 65.00m, Descripcion = "Habitación doble con vista al jardín interior del hotel.", Estado = EstadoHabitacion.Limpieza },
                    new Habitacion { Numero = "201", Tipo = "Suite", Capacidad = 6, NumeroCamas = 3, Piso = 2, Precio = 120.00m, Descripcion = "Suite amplia con sala de estar independiente, ideal para familias grandes o grupos.", Estado = EstadoHabitacion.Disponible },
                    new Habitacion { Numero = "202", Tipo = "Doble", Capacidad = 5, NumeroCamas = 2, Piso = 2, Precio = 70.00m, Descripcion = "Habitación doble con una cama extra disponible, balcón con vista a la ciudad.", Estado = EstadoHabitacion.Ocupada },
                    new Habitacion { Numero = "203", Tipo = "Sencilla", Capacidad = 2, NumeroCamas = 1, Piso = 2, Precio = 50.00m, Descripcion = "Habitación sencilla renovada, con aire acondicionado y smart TV.", Estado = EstadoHabitacion.Disponible },
                    new Habitacion { Numero = "301", Tipo = "Suite Presidencial", Capacidad = 6, NumeroCamas = 3, Piso = 3, Precio = 180.00m, Descripcion = "Nuestra suite más exclusiva: jacuzzi privado, sala de estar, minibar y vista panorámica.", Estado = EstadoHabitacion.Disponible },
                    new Habitacion { Numero = "302", Tipo = "Doble", Capacidad = 4, NumeroCamas = 2, Piso = 3, Precio = 75.00m, Descripcion = "Habitación doble en el piso más alto del hotel, ambiente tranquilo y silencioso.", Estado = EstadoHabitacion.Mantenimiento }
                );
            }

            // Las imágenes del catálogo inicial se instalan también en bases
            // anteriores. Nunca sustituimos una URL elegida por el administrador.
            var imagenesHabitaciones = new Dictionary<string, string>
            {
                ["101"] = "/images/room-101.webp", ["102"] = "/images/room-102.webp",
                ["103"] = "/images/room-103.webp", ["201"] = "/images/room-201.webp",
                ["202"] = "/images/room-202.webp", ["203"] = "/images/room-203.webp",
                ["301"] = "/images/room-301.webp", ["302"] = "/images/room-302.webp"
            };
            var numeros = imagenesHabitaciones.Keys.ToArray();
            var habitacionesExistentes = await context.Habitaciones
                .Where(h => numeros.Contains(h.Numero)).ToListAsync();
            foreach (var habitacion in context.Habitaciones.Local.Concat(habitacionesExistentes))
            {
                if (string.IsNullOrWhiteSpace(habitacion.ImagenUrl) &&
                    imagenesHabitaciones.TryGetValue(habitacion.Numero, out var imagen))
                    habitacion.ImagenUrl = imagen;
            }

            await context.SaveChangesAsync();

            // En una instalación realmente nueva se crean las cuentas de demostración.
            // Después no se recrean automáticamente: si el administrador elimina un empleado,
            // la decisión se respeta en los siguientes arranques.
            if (instalacionNueva)
            {
                await AsegurarEmpleadoInicialAsync(userManager, context, "administrador.hotel@gmail.com", "Admin123!",
                    RolAdministrador, "Administrador", "General", "00000000-0", cargoAdministradorId, horarioMananaId);
                await AsegurarEmpleadoInicialAsync(userManager, context, "secretario.hotel@gmail.com", "Secretario123!",
                    RolSecretario, "Secretario", "Recepción", "11111111-1", cargoSecretarioId, horarioMananaId);
            }
            else
            {
                await NormalizarCargoCuentaExistenteAsync(userManager, context, "administrador.hotel@gmail.com", cargoAdministradorId);
                await NormalizarCargoCuentaExistenteAsync(userManager, context, "secretario.hotel@gmail.com", cargoSecretarioId);
            }
        }

        private static async Task NormalizarCargoCuentaExistenteAsync(UserManager<IdentityUser> userManager,
            ApplicationDbContext context, string email, int cargoId)
        {
            var usuario = await userManager.FindByEmailAsync(email);
            if (usuario == null) return;
            var perfil = await context.Empleados.FirstOrDefaultAsync(e => e.AspNetUserId == usuario.Id);
            if (perfil == null) return;
            if (perfil.CargoId != cargoId)
            {
                perfil.CargoId = cargoId;
                await context.SaveChangesAsync();
            }
        }

        private static async Task AsegurarEmpleadoInicialAsync(UserManager<IdentityUser> userManager,
            ApplicationDbContext context, string email, string password, string rol, string nombre, string apellido,
            string dui, int cargoId, int horarioId)
        {
            var usuario = await userManager.FindByEmailAsync(email);
            if (usuario == null)
            {
                usuario = new IdentityUser { UserName = email, Email = email, EmailConfirmed = true, LockoutEnabled = true };
                VerificarResultado(await userManager.CreateAsync(usuario, password), $"crear la cuenta {email}");
            }
            if (!await userManager.IsInRoleAsync(usuario, rol))
                VerificarResultado(await userManager.AddToRoleAsync(usuario, rol), $"asignar el rol {rol} a {email}");

            var claims = await userManager.GetClaimsAsync(usuario);
            if (!claims.Any(c => c.Type == "EstadoEmpleado"))
                VerificarResultado(await userManager.AddClaimAsync(usuario, new Claim("EstadoEmpleado", "Activo")),
                    $"activar la cuenta {email}");

            var perfil = await context.Empleados.FirstOrDefaultAsync(e => e.AspNetUserId == usuario.Id);
            if (perfil == null)
            {
                // En una base antigua el DUI puede pertenecer ya al mismo empleado con otro AspNetUserId.
                perfil = await context.Empleados.FirstOrDefaultAsync(e => e.Dui == dui);
            }
            if (perfil == null)
            {
                context.Empleados.Add(new Empleado
                {
                    AspNetUserId = usuario.Id, Nombre = nombre, Apellido = apellido,
                    FechaNacimiento = new DateTime(1990, 1, 1), Dui = dui,
                    CargoId = cargoId, HorarioId = horarioId
                });
            }
            else
            {
                perfil.AspNetUserId = usuario.Id;
                perfil.CargoId = cargoId;
                if (perfil.HorarioId == 0) perfil.HorarioId = horarioId;
            }
            await context.SaveChangesAsync();
        }

        private static async Task<int> ObtenerOCrearCargoAsync(ApplicationDbContext context, string nombre)
        {
            var cargo = await context.Cargos.FirstOrDefaultAsync(c => c.Nombre == nombre);
            if (cargo == null)
            {
                cargo = new Cargo { Nombre = nombre, Descripcion = nombre };
                context.Cargos.Add(cargo);
                await context.SaveChangesAsync();
            }
            return cargo.Id;
        }

        private static async Task<int> ObtenerOCrearHorarioAsync(ApplicationDbContext context, string turno, string descripcion)
        {
            var horario = await context.Horarios.FirstOrDefaultAsync(h => h.Turno == turno);
            if (horario == null)
            {
                horario = new Horario { Turno = turno, Descripcion = descripcion };
                context.Horarios.Add(horario);
            }
            else
            {
                horario.Descripcion = descripcion;
            }
            await context.SaveChangesAsync();
            return horario.Id;
        }

        private static async Task AsignarPermisosARolAsync(
            RoleManager<IdentityRole> roleManager, string nombreRol, IEnumerable<string> permisos)
        {
            var rol = await roleManager.FindByNameAsync(nombreRol)
                ?? throw new InvalidOperationException($"No existe el rol {nombreRol}.");

            var existentes = (await roleManager.GetClaimsAsync(rol))
                .Where(c => c.Type == "Permission")
                .Select(c => c.Value)
                .ToHashSet();

            foreach (var permiso in permisos.Where(p => !existentes.Contains(p)))
            {
                var result = await roleManager.AddClaimAsync(rol, new Claim("Permission", permiso));
                VerificarResultado(result, $"asignar {permiso} a {nombreRol}");
            }
        }

        private static void VerificarResultado(IdentityResult result, string accion)
        {
            if (result.Succeeded) return;
            throw new InvalidOperationException(
                $"No se pudo {accion}: {string.Join("; ", result.Errors.Select(e => e.Description))}");
        }
    }
}
