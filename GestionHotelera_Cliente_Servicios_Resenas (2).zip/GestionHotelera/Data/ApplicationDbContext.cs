using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GestionHotelera.Models.Entidades;

namespace GestionHotelera.Data
{
    // Hereda de IdentityDbContext: EF crea automáticamente (por migraciones)
    // las tablas AspNetUsers, AspNetRoles, AspNetUserRoles, etc.
    // Usamos IdentityRole con Id string (comportamiento por defecto de Identity).
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Cargo> Cargos => Set<Cargo>();
        public DbSet<Horario> Horarios => Set<Horario>();
        public DbSet<Empleado> Empleados => Set<Empleado>();
        public DbSet<Cliente> Clientes => Set<Cliente>();
        public DbSet<Habitacion> Habitaciones => Set<Habitacion>();
        public DbSet<Reserva> Reservas => Set<Reserva>();
        public DbSet<Pago> Pagos => Set<Pago>();
        public DbSet<SolicitudServicio> SolicitudesServicio => Set<SolicitudServicio>();
        public DbSet<Resena> Resenas => Set<Resena>();

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Empleado>()
                .HasIndex(e => e.AspNetUserId)
                .IsUnique();

            builder.Entity<Empleado>()
                .HasIndex(e => e.Dui)
                .IsUnique();

            builder.Entity<Cliente>()
                .HasIndex(c => c.AspNetUserId)
                .IsUnique();

            builder.Entity<Habitacion>()
                .HasIndex(h => h.Numero)
                .IsUnique();

            builder.Entity<Resena>()
                .HasIndex(r => r.ReservaId)
                .IsUnique();

            // Guardamos los enums como texto (Disponible, Confirmada, etc.)
            // en vez de números, para que sea legible en la base de datos.
            builder.Entity<Habitacion>()
                .Property(h => h.Estado)
                .HasConversion<string>()
                .HasMaxLength(20);

            builder.Entity<Reserva>()
                .Property(r => r.EstadoReserva)
                .HasConversion<string>()
                .HasMaxLength(20);

            builder.Entity<SolicitudServicio>()
                .Property(s => s.Estado)
                .HasConversion<string>()
                .HasMaxLength(20);

            // Evitar borrados en cascada accidentales que dejen sin sentido
            // el historial de reservas/pagos.
            builder.Entity<Reserva>()
                .HasOne(r => r.Empleado)
                .WithMany()
                .OnDelete(DeleteBehavior.SetNull);

            // No permitir borrar una habitación que ya tiene reservas
            // registradas (se debe conservar el historial). El intento de
            // borrado fallará con una excepción que capturamos en el
            // controlador para mostrar un mensaje amigable.
            builder.Entity<Reserva>()
                .HasOne(r => r.Habitacion)
                .WithMany(h => h.Reservas)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Reserva>()
                .HasOne(r => r.Cliente)
                .WithMany(c => c.Reservas)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
