document.addEventListener('DOMContentLoaded', () => {
  const addOneDay = value => {
    const date = new Date(value + 'T12:00:00');
    date.setDate(date.getDate() + 1);
    return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('-');
  };

  const search = document.querySelector('[data-search-form]');
  if (search) {
    const start = search.querySelector('[name="FechaEntrada"]');
    const end = search.querySelector('[name="FechaSalida"]');
    const sync = () => {
      end.min = start.value ? addOneDay(start.value) : end.dataset.minInitial;
      if (end.value && start.value && end.value <= start.value) end.value = '';
      start.setCustomValidity('');
      end.setCustomValidity('');
    };
    end.dataset.minInitial = end.min;
    start.addEventListener('change', sync);
    end.addEventListener('change', sync);
    search.addEventListener('submit', event => {
      if (!!start.value !== !!end.value) {
        event.preventDefault();
        (start.value ? end : start).setCustomValidity('Selecciona tanto la fecha de entrada como la de salida.');
        (start.value ? end : start).reportValidity();
      }
    });
    sync();
  }

  const booking = document.querySelector('[data-booking-panel]');
  if (booking && booking.querySelector('[name="FechaEntrada"]')) {
    const start = booking.querySelector('[name="FechaEntrada"]');
    const end = booking.querySelector('[name="FechaSalida"]');
    const status = booking.querySelector('[data-availability-status]');
    const estimate = booking.querySelector('[data-booking-estimate]');
    const submit = booking.querySelector('[data-booking-submit]');
    let timer;
    let request;
    const formatMoney = new Intl.NumberFormat('es-SV', { style: 'currency', currency: 'USD' });
    const update = () => {
      clearTimeout(timer);
      request?.abort();
      submit.disabled = true;
      estimate.hidden = true;
      if (start.value) {
        end.min = addOneDay(start.value);
        if (end.value && end.value <= start.value) end.value = '';
      }
      if (!start.value || !end.value) {
        status.textContent = 'Elige entrada y salida para consultar disponibilidad.';
        return;
      }
      const nights = Math.round((Date.parse(end.value + 'T12:00:00') - Date.parse(start.value + 'T12:00:00')) / 86400000);
      if (nights < 1 || nights > 730) {
        status.textContent = 'Selecciona una salida posterior a la entrada.';
        return;
      }
      estimate.textContent = nights + (nights === 1 ? ' noche · ' : ' noches · ') +
        formatMoney.format(nights * Number(booking.dataset.price)) + ' total estimado';
      estimate.hidden = false;
      status.textContent = 'Comprobando disponibilidad…';
      timer = setTimeout(async () => {
        request = new AbortController();
        try {
          const url = new URL(booking.dataset.availabilityUrl, window.location.href);
          url.searchParams.set('entrada', start.value);
          url.searchParams.set('salida', end.value);
          const response = await fetch(url, { signal: request.signal });
          if (!response.ok) throw new Error('availability');
          const data = await response.json();
          status.textContent = data.disponible ? 'Disponible para estas fechas.' : 'Ya reservada para estas fechas. Elige otras.';
          submit.disabled = !data.disponible;
        } catch (error) {
          if (error.name !== 'AbortError') status.textContent = 'No se pudo consultar. Vuelve a elegir las fechas.';
        }
      }, 260);
    };
    start.addEventListener('change', update);
    end.addEventListener('change', update);
    update();
  }

  const checkout = document.querySelector('[data-checkout-form]');
  if (checkout) {
    checkout.addEventListener('submit', event => {
      if (!checkout.checkValidity()) return;
      const button = checkout.querySelector('[data-pay-button]');
      const status = checkout.querySelector('[data-pay-status]');
      if (checkout.dataset.submitted === 'true') {
        event.preventDefault();
        return;
      }
      checkout.dataset.submitted = 'true';
      button.disabled = true;
      status.textContent = 'Comprobando la disponibilidad y procesando el pago de prueba…';
    });
  }

  document.querySelectorAll('[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  document.querySelectorAll('[data-table-search]').forEach(input => {
    const table = document.getElementById(input.dataset.tableSearch);
    const count = document.getElementById(input.id === 'teamSearch' ? 'teamCount' : 'inventoryCount');
    if (!table) return;
    const rows = [...table.querySelectorAll('tbody [data-search-row]')];
    const normal = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    const filter = () => {
      const term = normal(input.value.trim());
      let visible = 0;
      rows.forEach(row => {
        row.hidden = !normal(row.textContent).includes(term);
        if (!row.hidden) visible++;
      });
      if (count) count.textContent = visible + (visible === 1 ? ' resultado' : ' resultados');
    };
    input.addEventListener('input', filter);
    filter();
  });

  if (window.IntersectionObserver && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('js-motion');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: .06 });
    document.querySelectorAll('[data-reveal]').forEach(element => observer.observe(element));
  }
});
