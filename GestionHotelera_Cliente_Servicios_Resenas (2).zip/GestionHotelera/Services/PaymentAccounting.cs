using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;

namespace GestionHotelera.Services
{
    // Las tarjetas del checkout son de prueba. Sus registros sirven para
    // mostrar el recorrido al huésped, pero nunca cancelan una deuda real.
    public static class PaymentAccounting
    {
        public const string TestPrefix = "Prueba ";

        public static bool IsTest(Pago pago) =>
            pago.MetodoPago.StartsWith(TestPrefix, StringComparison.Ordinal);

        public static decimal RealPaid(IEnumerable<Pago> payments) =>
            payments.Where(p => !IsTest(p)).Sum(p => p.Monto);

        public static decimal Outstanding(Reserva reservation) =>
            reservation.EstadoReserva == EstadoReserva.Cancelada
                ? 0
                : Math.Max(0, reservation.Total - RealPaid(reservation.Pagos));

        public static IQueryable<Pago> RealPayments(IQueryable<Pago> payments) =>
            payments.Where(p => !p.MetodoPago.StartsWith(TestPrefix));
    }
}
