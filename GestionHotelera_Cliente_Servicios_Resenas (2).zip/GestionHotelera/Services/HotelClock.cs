namespace GestionHotelera.Services
{
    // Las fechas de reserva son fechas del hotel, independientemente de la
    // zona horaria configurada en el servidor web.
    public static class HotelClock
    {
        private static readonly TimeZoneInfo Zone = ObtenerZona();

        public static DateTime Now => TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Zone);
        public static DateTime Today => Now.Date;

        private static TimeZoneInfo ObtenerZona()
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById("America/El_Salvador");
            }
            catch (TimeZoneNotFoundException)
            {
                return TimeZoneInfo.CreateCustomTimeZone("Hotel UTC-6",
                    TimeSpan.FromHours(-6), "Hora del hotel", "Hora del hotel");
            }
        }
    }
}
