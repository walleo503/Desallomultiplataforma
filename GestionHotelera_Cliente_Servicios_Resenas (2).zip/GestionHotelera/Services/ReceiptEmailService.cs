using System.Net;
using System.Net.Mail;

namespace GestionHotelera.Services
{
    public class ReceiptEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<ReceiptEmailService> _logger;

        public ReceiptEmailService(IConfiguration configuration, ILogger<ReceiptEmailService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public bool EstaConfigurado =>
            _configuration.GetValue<bool>("Email:Enabled") &&
            !string.IsNullOrWhiteSpace(_configuration["Email:SenderEmail"]) &&
            !string.IsNullOrWhiteSpace(_configuration["Email:AppPassword"]);

        public async Task<bool> EnviarComprobanteAsync(string destinatario, string nombreCliente, int reservaId, byte[] pdf)
        {
            if (!EstaConfigurado || string.IsNullOrWhiteSpace(destinatario)) return false;

            try
            {
                var host = _configuration["Email:SmtpHost"] ?? "smtp.gmail.com";
                var puerto = _configuration.GetValue<int?>("Email:SmtpPort") ?? 587;
                var remitente = _configuration["Email:SenderEmail"]!;
                var clave = _configuration["Email:AppPassword"]!;
                var nombreRemitente = _configuration["Email:SenderName"] ?? "Ámbar Estancias";

                using var mensaje = new MailMessage
                {
                    From = new MailAddress(remitente, nombreRemitente),
                    Subject = $"Comprobante de pago - Reserva #{reservaId}",
                    Body = $"Hola {nombreCliente},\n\nAdjuntamos el comprobante del pago registrado para tu reserva #{reservaId}.\n\nÁmbar Estancias",
                    IsBodyHtml = false
                };
                mensaje.To.Add(destinatario);
                mensaje.Attachments.Add(new Attachment(new MemoryStream(pdf), $"comprobante-reserva-{reservaId}.pdf", "application/pdf"));

                using var smtp = new SmtpClient(host, puerto)
                {
                    EnableSsl = true,
                    Credentials = new NetworkCredential(remitente, clave)
                };
                await smtp.SendMailAsync(mensaje);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "No se pudo enviar el comprobante de la reserva {ReservaId} a {Destinatario}", reservaId, destinatario);
                return false;
            }
        }
    }
}
