using System.Globalization;
using System.Text;
using GestionHotelera.Models.Entidades;

namespace GestionHotelera.Services
{
    public class PaymentReceiptPdfService
    {
        public byte[] Crear(Reserva reserva, Pago pago, string correoCliente)
        {
            var cliente = $"{reserva.Cliente?.Nombre} {reserva.Cliente?.Apellido}".Trim();
            var habitacion = $"{reserva.Habitacion?.Numero} - {reserva.Habitacion?.Tipo}";
            var totalPagado = PaymentAccounting.RealPaid(reserva.Pagos);
            var saldo = Math.Max(0, reserva.Total - totalPagado);
            var recibido = pago.MontoRecibido ?? pago.Monto;
            var cambio = pago.Cambio ?? 0;

            var lineas = new List<(string Texto, bool Negrita, int Tamano, int Y)>
            {
                ("AMBAR ESTANCIAS", true, 20, 742),
                ("COMPROBANTE DE PAGO", true, 15, 716),
                ($"Pago #{pago.Id}  |  Reserva #{reserva.Id}", false, 10, 692),
                ($"Fecha: {pago.FechaPago:dd/MM/yyyy HH:mm}", false, 10, 676),
                ("", false, 10, 660),
                ($"Cliente: {cliente}", true, 11, 638),
                ($"Correo: {correoCliente}", false, 10, 620),
                ($"Habitacion: {habitacion}", false, 10, 602),
                ($"Estadia: {reserva.FechaEntrada:dd/MM/yyyy} - {reserva.FechaSalida:dd/MM/yyyy}", false, 10, 584),
                ($"Huespedes: {reserva.CantidadHuespedes}", false, 10, 566),
                ("", false, 10, 548),
                ($"Metodo de pago: {pago.MetodoPago}", false, 11, 526),
                ($"Total de la reserva: {Dinero(reserva.Total)}", false, 11, 504),
                ($"Monto aplicado: {Dinero(pago.Monto)}", true, 12, 482),
            };

            if (pago.MetodoPago == "Efectivo")
            {
                lineas.Add(($"Efectivo recibido: {Dinero(recibido)}", false, 11, 460));
                lineas.Add(($"Cambio: {Dinero(cambio)}", true, 12, 438));
                lineas.Add(($"Total pagado acumulado: {Dinero(totalPagado)}", false, 11, 416));
                lineas.Add(($"Saldo restante: {Dinero(saldo)}", true, 12, 394));
            }
            else
            {
                lineas.Add(($"Total pagado acumulado: {Dinero(totalPagado)}", false, 11, 460));
                lineas.Add(($"Saldo restante: {Dinero(saldo)}", true, 12, 438));
            }

            lineas.Add((saldo == 0 ? "ESTADO: PAGADO" : "ESTADO: SALDO PENDIENTE", true, 13, 350));
            lineas.Add(("Conserve este comprobante como constancia del pago registrado.", false, 9, 318));
            lineas.Add(("Documento generado por el sistema de Gestion Hotelera.", false, 9, 302));

            return CrearPdfSimple(lineas);
        }

        private static string Dinero(decimal valor) => "$" + valor.ToString("0.00", CultureInfo.InvariantCulture);

        private static byte[] CrearPdfSimple(IEnumerable<(string Texto, bool Negrita, int Tamano, int Y)> lineas)
        {
            var contenido = new StringBuilder();
            contenido.AppendLine("0.15 w");
            contenido.AppendLine("55 705 m 557 705 l S");
            contenido.AppendLine("55 370 m 557 370 l S");
            foreach (var linea in lineas)
            {
                if (string.IsNullOrEmpty(linea.Texto)) continue;
                contenido.Append("BT /").Append(linea.Negrita ? "F2" : "F1").Append(' ')
                    .Append(linea.Tamano).Append(" Tf 55 ").Append(linea.Y).Append(" Td (")
                    .Append(EscapePdf(QuitarDiacriticos(linea.Texto))).AppendLine(") Tj ET");
            }

            var stream = Encoding.ASCII.GetBytes(contenido.ToString());
            var objetos = new List<byte[]>
            {
                Bytes("<< /Type /Catalog /Pages 2 0 R >>"),
                Bytes("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"),
                Bytes("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>"),
                Combinar(Bytes($"<< /Length {stream.Length} >>\nstream\n"), stream, Bytes("\nendstream")),
                Bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),
                Bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
            };

            using var ms = new MemoryStream();
            Escribir(ms, "%PDF-1.4\n%AMBAR\n");
            var offsets = new List<long> { 0 };
            for (var i = 0; i < objetos.Count; i++)
            {
                offsets.Add(ms.Position);
                Escribir(ms, $"{i + 1} 0 obj\n");
                ms.Write(objetos[i]);
                Escribir(ms, "\nendobj\n");
            }

            var xref = ms.Position;
            Escribir(ms, $"xref\n0 {objetos.Count + 1}\n0000000000 65535 f \n");
            for (var i = 1; i < offsets.Count; i++) Escribir(ms, $"{offsets[i]:D10} 00000 n \n");
            Escribir(ms, $"trailer\n<< /Size {objetos.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF");
            return ms.ToArray();
        }

        private static string QuitarDiacriticos(string texto)
        {
            var normalizado = texto.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (var c in normalizado)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }
            return sb.ToString().Normalize(NormalizationForm.FormC).Replace('ñ', 'n').Replace('Ñ', 'N');
        }

        private static string EscapePdf(string texto) => texto.Replace("\\", "\\\\").Replace("(", "\\(").Replace(")", "\\)");
        private static byte[] Bytes(string texto) => Encoding.ASCII.GetBytes(texto);
        private static byte[] Combinar(params byte[][] partes)
        {
            using var ms = new MemoryStream();
            foreach (var parte in partes) ms.Write(parte);
            return ms.ToArray();
        }
        private static void Escribir(Stream stream, string texto)
        {
            var bytes = Encoding.ASCII.GetBytes(texto);
            stream.Write(bytes);
        }
    }
}
