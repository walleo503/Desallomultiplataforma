using GestionHotelera.Data;
using Microsoft.EntityFrameworkCore;

namespace GestionHotelera.Services
{
    public static class DatabaseLocation
    {
        // Mostrar únicamente el host y el nombre de la base: nunca la cadena de conexión.
        public static string Description(ApplicationDbContext context)
        {
            var connection = context.Database.GetDbConnection();
            var host = connection.DataSource;
            var database = connection.Database;
            var origin = $"Instancia: {Environment.MachineName} · MySQL: {host} / {database}.";
            var local = host.Equals("localhost", StringComparison.OrdinalIgnoreCase) ||
                host.StartsWith("localhost:", StringComparison.OrdinalIgnoreCase) ||
                host.StartsWith("127.0.0.1", StringComparison.Ordinal) || host == "::1";

            return local
                ? origin + " Si ejecutas la aplicación en otra PC con localhost, sus reservas y saldos no se comparten."
                : origin;
        }
    }
}
