namespace GestionHotelera.Models.Enums
{
    public enum EstadoEmpleado
    {
        Activo,
        Suspendido,
        Despedido
    }
}
