namespace GestionHotelera.Models.Enums
{
    // Estados operativos de una habitación (según Objetivos del sistema)
    public enum EstadoHabitacion
    {
        Disponible,
        Ocupada,
        Limpieza,
        Mantenimiento
    }
}
