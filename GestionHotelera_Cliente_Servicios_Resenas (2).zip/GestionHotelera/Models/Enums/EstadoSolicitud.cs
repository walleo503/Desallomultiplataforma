namespace GestionHotelera.Models.Enums
{
    public enum EstadoSolicitud
    {
        Pendiente,
        EnProceso,
        Completada
    }
}
