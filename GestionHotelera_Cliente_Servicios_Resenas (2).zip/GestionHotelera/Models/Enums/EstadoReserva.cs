namespace GestionHotelera.Models.Enums
{
    // Estado de la reservación, independiente del estado de la habitación
    public enum EstadoReserva
    {
        Confirmada,
        CheckInRealizado,
        Finalizada,
        Cancelada
    }
}
