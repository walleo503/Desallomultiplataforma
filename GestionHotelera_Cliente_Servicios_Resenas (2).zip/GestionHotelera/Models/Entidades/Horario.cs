using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Entidades
{
    public class Horario
    {
        public int Id { get; set; }

        // "Mañana" | "Tarde" | "Noche"
        [Required, MaxLength(50)]
        public string Turno { get; set; } = string.Empty;

        [MaxLength(150)]
        public string? Descripcion { get; set; }
    }
}
