using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GestionHotelera.Models.Enums;

namespace GestionHotelera.Models.Entidades
{
    // Perfil extendido de personal dado de alta desde el módulo de equipo.
    // El login (usuario/contraseña) y el ROL viven en Identity
    // (AspNetUsers / AspNetRoles). Aquí solo va la info del hotel.
    public class Empleado
    {
        public int Id { get; set; }

        // Id del IdentityUser (AspNetUsers.Id) dueño de esta cuenta
        [Required]
        public string AspNetUserId { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Date)]
        public DateTime FechaNacimiento { get; set; }

        [MaxLength(20)]
        public string? Sexo { get; set; }

        [Required, MaxLength(15)]
        public string Dui { get; set; } = string.Empty;

        [Required]
        public int CargoId { get; set; }
        public Cargo? Cargo { get; set; }

        [Required]
        public int HorarioId { get; set; }
        public Horario? Horario { get; set; }

        // El estado laboral se conserva como claim de Identity para no alterar la tabla existente.
        [NotMapped]
        public EstadoEmpleado Estado { get; set; } = EstadoEmpleado.Activo;

        // Se calcula, no se guarda directamente en BD (evita que quede desactualizada)
        [NotMapped]
        public int Edad
        {
            get
            {
                var hoy = GestionHotelera.Services.HotelClock.Today;
                var edad = hoy.Year - FechaNacimiento.Year;
                return FechaNacimiento.Date.AddYears(edad) > hoy ? edad - 1 : edad;
            }
        }
    }
}
