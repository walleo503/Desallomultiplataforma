using System.ComponentModel.DataAnnotations;
using GestionHotelera.Models.Enums;

namespace GestionHotelera.Models.Entidades
{
    public class SolicitudServicio
    {
        public int Id { get; set; }

        [Required]
        public int ReservaId { get; set; }
        public Reserva? Reserva { get; set; }

        [Required, MaxLength(100)]
        public string TipoServicio { get; set; } = string.Empty; // Limpieza, Comida, etc.

        [MaxLength(255)]
        public string? Descripcion { get; set; }

        [Required]
        public EstadoSolicitud Estado { get; set; } = EstadoSolicitud.Pendiente;

        public DateTime FechaSolicitud { get; set; } = GestionHotelera.Services.HotelClock.Now;
    }
}
