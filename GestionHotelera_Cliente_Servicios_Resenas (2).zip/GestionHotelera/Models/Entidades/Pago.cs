using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GestionHotelera.Models.Entidades
{
    public class Pago
    {
        public int Id { get; set; }

        [Required]
        public int ReservaId { get; set; }
        public Reserva? Reserva { get; set; }

        // Importe que realmente se aplica al saldo de la reserva.
        [Required, Column(TypeName = "decimal(10,2)")]
        public decimal Monto { get; set; }

        // En efectivo puede ser mayor que Monto. Ej.: saldo $65, recibe $100.
        [Column(TypeName = "decimal(10,2)")]
        public decimal? MontoRecibido { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal? Cambio { get; set; }

        public DateTime FechaPago { get; set; } = GestionHotelera.Services.HotelClock.Now;

        [Required, MaxLength(50)]
        public string MetodoPago { get; set; } = string.Empty; // Efectivo, Tarjeta, Transferencia
    }
}
