using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Entidades
{
    public class Cargo
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [MaxLength(150)]
        public string? Descripcion { get; set; }
    }
}
