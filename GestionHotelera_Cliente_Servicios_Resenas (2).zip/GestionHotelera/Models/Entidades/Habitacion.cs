using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GestionHotelera.Models.Enums;

namespace GestionHotelera.Models.Entidades
{
    public class Habitacion
    {
        public int Id { get; set; }

        [Required, MaxLength(20)]
        public string Numero { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Tipo { get; set; } = string.Empty;

        [Required, Range(1, 20)]
        public int Capacidad { get; set; }

        [Required, Range(1, 10)]
        public int NumeroCamas { get; set; }

        [Required, Range(0, 50)]
        public int Piso { get; set; }

        [Required, Column(TypeName = "decimal(10,2)")]
        public decimal Precio { get; set; }

        [Required, MaxLength(255)]
        public string Descripcion { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? ImagenUrl { get; set; }

        [Required]
        public EstadoHabitacion Estado { get; set; } = EstadoHabitacion.Disponible;

        public ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();

    }
}
