using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Entidades
{
    public class Resena
    {
        public int Id { get; set; }

        [Required]
        public int ReservaId { get; set; }
        public Reserva? Reserva { get; set; }

        [Required, Range(1, 5)]
        public int Calificacion { get; set; }

        [MaxLength(500)]
        public string? Comentario { get; set; }

        public DateTime Fecha { get; set; } = GestionHotelera.Services.HotelClock.Now;
    }
}
