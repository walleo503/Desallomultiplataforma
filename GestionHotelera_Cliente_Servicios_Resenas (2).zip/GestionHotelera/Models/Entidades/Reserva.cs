using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using GestionHotelera.Models.Enums;
using GestionHotelera.Services;

namespace GestionHotelera.Models.Entidades
{
    public class Reserva
    {
        public int Id { get; set; }

        [Required]
        public int HabitacionId { get; set; }
        public Habitacion? Habitacion { get; set; }

        [Required]
        public int ClienteId { get; set; }
        public Cliente? Cliente { get; set; }

        // Secretario que gestionó la reserva (null = la hizo el cliente)
        public int? EmpleadoId { get; set; }
        public Empleado? Empleado { get; set; }

        public DateTime FechaReserva { get; set; } = HotelClock.Now;

        [Required, DataType(DataType.Date)]
        public DateTime FechaEntrada { get; set; }

        [Required, DataType(DataType.Date)]
        public DateTime FechaSalida { get; set; }

        [Required, Range(1, 20)]
        public int CantidadHuespedes { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal Total { get; set; }

        [Required]
        public EstadoReserva EstadoReserva { get; set; } = EstadoReserva.Confirmada;

        public ICollection<Pago> Pagos { get; set; } = new List<Pago>();
        public ICollection<SolicitudServicio> Solicitudes { get; set; } = new List<SolicitudServicio>();
        public Resena? Resena { get; set; }
    }
}
