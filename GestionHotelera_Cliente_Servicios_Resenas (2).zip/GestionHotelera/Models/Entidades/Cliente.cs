using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Entidades
{
    // Perfil extendido de un cliente/huésped, ligado a su IdentityUser.
    public class Cliente
    {
        public int Id { get; set; }

        [Required]
        public string AspNetUserId { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [MaxLength(15)]
        public string? Dui { get; set; }

        [MaxLength(20)]
        public string? Telefono { get; set; }

        public ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
    }
}
