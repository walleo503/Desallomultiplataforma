namespace GestionHotelera.Models.Reportes
{
    public class ResumenIngresosViewModel
    {
        public int Anio { get; set; }
        public decimal Total { get; set; }
        public int CantidadPagos { get; set; }
        public List<IngresoMensual> Meses { get; set; } = new();
    }

    public class IngresoMensual
    {
        public int Numero { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public decimal Total { get; set; }
        public int Pagos { get; set; }
    }
}
