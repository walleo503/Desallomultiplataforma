using System.ComponentModel.DataAnnotations;
using GestionHotelera.Models.Enums;
using Microsoft.AspNetCore.Http;

namespace GestionHotelera.Models.Habitaciones
{
    public class HabitacionFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Indica el número de habitación.")]
        [MaxLength(20)]
        public string Numero { get; set; } = string.Empty;

        [Required(ErrorMessage = "Indica el tipo de habitación.")]
        [MaxLength(100)]
        public string Tipo { get; set; } = string.Empty;

        [Required]
        [Range(1, 20, ErrorMessage = "La capacidad debe ser entre 1 y 20 personas.")]
        public int Capacidad { get; set; }

        [Required]
        [Range(1, 10, ErrorMessage = "El número de camas debe ser entre 1 y 10.")]
        public int NumeroCamas { get; set; }

        [Required]
        [Range(0, 50, ErrorMessage = "El piso debe ser un número válido.")]
        public int Piso { get; set; }

        [Required]
        [Range(0.01, 100000, ErrorMessage = "Indica un precio válido.")]
        public decimal Precio { get; set; }

        [Required(ErrorMessage = "Agrega una descripción de la habitación.")]
        [MaxLength(255)]
        public string Descripcion { get; set; } = string.Empty;

        [MaxLength(500)]
        [Display(Name = "URL de la imagen (opcional)")]
        public string? ImagenUrl { get; set; }

        [Display(Name = "Imagen de la habitación")]
        public IFormFile? ImagenArchivo { get; set; }

        [Required]
        public EstadoHabitacion Estado { get; set; } = EstadoHabitacion.Disponible;
    }
}
