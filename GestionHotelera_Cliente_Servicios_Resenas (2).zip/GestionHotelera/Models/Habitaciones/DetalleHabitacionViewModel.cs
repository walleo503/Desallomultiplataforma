using System.ComponentModel.DataAnnotations;
using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;

namespace GestionHotelera.Models.Habitaciones
{
    public class DetalleHabitacionViewModel
    {
        public int Id { get; set; }
        public string Numero { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public int Capacidad { get; set; }
        public int NumeroCamas { get; set; }
        public int Piso { get; set; }
        public decimal Precio { get; set; }
        public string Descripcion { get; set; } = string.Empty;
        public string? ImagenUrl { get; set; }
        public EstadoHabitacion Estado { get; set; }

        public bool UsuarioNoAutenticado { get; set; }
        public bool UsuarioSinPerfilCliente { get; set; }
        public bool PuedeReservar => !UsuarioNoAutenticado && !UsuarioSinPerfilCliente;

        public bool PuedeGestionarReservas { get; set; }
        public List<Reserva> HistorialReservas { get; set; } = new();

        [DataType(DataType.Date)]
        public DateTime? FechaEntrada { get; set; }
        [DataType(DataType.Date)]
        public DateTime? FechaSalida { get; set; }
        public bool? DisponibleFechas { get; set; }
        [Range(1, 20)]
        public int CantidadHuespedes { get; set; } = 1;
    }
}
