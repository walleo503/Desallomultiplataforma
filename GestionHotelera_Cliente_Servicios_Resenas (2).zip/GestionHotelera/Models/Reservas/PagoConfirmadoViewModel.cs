namespace GestionHotelera.Models.Reservas
{
    public class PagoConfirmadoViewModel
    {
        public int PagoId { get; set; }
        public int ReservaId { get; set; }
        public string Cliente { get; set; } = string.Empty;
        public string CorreoCliente { get; set; } = string.Empty;
        public string Habitacion { get; set; } = string.Empty;
        public string MetodoPago { get; set; } = string.Empty;
        public DateTime FechaPago { get; set; }
        public decimal TotalReserva { get; set; }
        public decimal MontoAplicado { get; set; }
        public decimal MontoRecibido { get; set; }
        public decimal Cambio { get; set; }
        public decimal TotalPagado { get; set; }
        public decimal SaldoRestante { get; set; }
        public bool CorreoEnviado { get; set; }
        public bool CorreoAutomaticoConfigurado { get; set; }
    }
}
