using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Reservas
{
    public class CheckoutViewModel : ReservarHabitacionViewModel
    {
        [Required(ErrorMessage = "Selecciona una tarjeta de prueba.")]
        [RegularExpression("^(visa|mastercard|rechazo)$", ErrorMessage = "Selecciona una tarjeta de prueba válida.")]
        public string TarjetaPrueba { get; set; } = "visa";

        // El precio y los datos de la habitación se calculan en el servidor.
        public string NumeroHabitacion { get; set; } = string.Empty;
        public string TipoHabitacion { get; set; } = string.Empty;
        public string? ImagenUrl { get; set; }
        public decimal PrecioNoche { get; set; }
        public decimal Total { get; set; }
        public decimal PrecioVisto { get; set; }
        public int Noches { get; set; }
        public string? CorreoHuesped { get; set; }
    }
}
