using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Reservas
{
    public class ReservarHabitacionViewModel
    {
        [Required]
        public int HabitacionId { get; set; }

        // Solo se usa cuando Administrador/Secretario reserva a nombre de un huésped.
        public int? ClienteId { get; set; }

        [Required(ErrorMessage = "Indica la fecha de entrada.")]
        [DataType(DataType.Date)]
        public DateTime FechaEntrada { get; set; }

        [Required(ErrorMessage = "Indica la fecha de salida.")]
        [DataType(DataType.Date)]
        public DateTime FechaSalida { get; set; }

        [Required]
        [Range(1, 20, ErrorMessage = "La cantidad de huéspedes debe ser entre 1 y 20.")]
        public int CantidadHuespedes { get; set; }
    }
}
