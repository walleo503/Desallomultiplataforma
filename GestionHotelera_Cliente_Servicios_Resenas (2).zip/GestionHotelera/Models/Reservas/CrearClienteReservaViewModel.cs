using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Reservas
{
    // Datos mínimos para que Administrador/Secretario pueda crear un huésped
    // desde el mismo flujo de reservación. Se crea también su cuenta Identity.
    public class CrearClienteReservaViewModel
    {
        [Required]
        public int HabitacionId { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio.")]
        [StringLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es obligatorio.")]
        [StringLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "Ingresa un correo válido.")]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "El DUI es obligatorio.")]
        [RegularExpression(@"^\d{8}-\d$", ErrorMessage = "El DUI debe tener el formato 00000000-0.")]
        [StringLength(15)]
        public string Dui { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Ingresa un teléfono válido.")]
        [StringLength(20)]
        public string? Telefono { get; set; }

        [Required(ErrorMessage = "La contraseña es obligatoria.")]
        [StringLength(100, MinimumLength = 8, ErrorMessage = "La contraseña debe tener al menos 8 caracteres.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Confirma la contraseña.")]
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "Las contraseñas no coinciden.")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
