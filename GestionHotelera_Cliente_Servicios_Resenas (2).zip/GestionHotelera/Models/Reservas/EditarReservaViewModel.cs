using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GestionHotelera.Models.Reservas
{
    public class EditarReservaViewModel
    {
        public int Id { get; set; }
        public string ClienteNombre { get; set; } = string.Empty;

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Selecciona una habitación.")]
        public int HabitacionId { get; set; }

        [Required, DataType(DataType.Date)]
        public DateTime FechaEntrada { get; set; }

        [Required, DataType(DataType.Date)]
        public DateTime FechaSalida { get; set; }

        [Required, Range(1, 20)]
        public int CantidadHuespedes { get; set; }

        public List<SelectListItem> Habitaciones { get; set; } = new();
    }
}
