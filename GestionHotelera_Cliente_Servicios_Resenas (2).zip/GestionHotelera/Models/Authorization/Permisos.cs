using System.Reflection;

namespace GestionHotelera.Models.Authorization
{
    // Cada constante es un "permiso" concreto (Claim de tipo "Permission").
    // En vez de preguntar "¿qué ROL tiene el usuario?", preguntamos
    // "¿qué PERMISO tiene el usuario?" (igual que en el PDF de Roles y Autorización).
    //
    // Estos permisos se asignan por ROL (no por usuario) en DbSeeder.cs,
    // así que basta con dar de alta un empleado con rol "Secretario" para
    // que herede automáticamente todos los permisos de ese rol.
    public static class Permisos
    {
        // ---------- Empleados ----------
        public const string EmpleadosVer = "Empleados.Ver";
        public const string EmpleadosCrear = "Empleados.Crear";
        public const string EmpleadosEditar = "Empleados.Editar";
        public const string EmpleadosEliminar = "Empleados.Eliminar";

        // ---------- Habitaciones ----------
        public const string HabitacionesVer = "Habitaciones.Ver";
        public const string HabitacionesCrear = "Habitaciones.Crear";
        public const string HabitacionesEditar = "Habitaciones.Editar";
        public const string HabitacionesEliminar = "Habitaciones.Eliminar";
        public const string HabitacionesCambiarEstado = "Habitaciones.CambiarEstado"; // limpieza <-> disponible, mantenimiento

        // ---------- Reservaciones ----------
        public const string ReservasVerTodas = "Reservas.VerTodas";       // Admin/Secretario: todas las del hotel
        public const string ReservasVerPropias = "Reservas.VerPropias";   // Cliente: solo las suyas
        public const string ReservasCrear = "Reservas.Crear";             // Cliente o Secretario a nombre del cliente
        public const string ReservasCancelar = "Reservas.Cancelar";
        public const string ReservasExtender = "Reservas.Extender";
        public const string ReservasCheckIn = "Reservas.CheckIn";
        public const string ReservasCheckOut = "Reservas.CheckOut";

        // ---------- Solicitudes de servicio ----------
        public const string SolicitudesCrear = "Solicitudes.Crear";           // Cliente
        public const string SolicitudesVerPropias = "Solicitudes.VerPropias"; // Cliente
        public const string SolicitudesGestionar = "Solicitudes.Gestionar";   // Secretario: ver todas + cambiar estado

        // ---------- Pagos y reportes ----------
        public const string PagosRegistrar = "Pagos.Registrar";           // Secretario
        public const string ReportesVerIngresos = "Reportes.VerIngresos"; // Administrador

        // ---------- Reseñas ----------
        public const string ResenasCrear = "Resenas.Crear"; // Cliente, solo tras finalizar estadía

        // Devuelve todos los permisos definidos arriba, usando reflexión.
        // Se usa en Program.cs para registrar una Policy por cada permiso
        // sin tener que escribirlas todas a mano una por una.
        public static IEnumerable<string> Todos()
        {
            return typeof(Permisos)
                .GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)
                .Where(f => f.IsLiteral && !f.IsInitOnly && f.FieldType == typeof(string))
                .Select(f => (string)f.GetRawConstantValue()!);
        }
    }
}
