using Microsoft.AspNetCore.Mvc.Rendering;

namespace GestionHotelera.Models.Home
{
    public class FiltroHabitacionesViewModel
    {
        // ---- Filtros seleccionados por el usuario (vienen del querystring) ----
        public int? Piso { get; set; }

        // Rango de capacidad, ej. "de 4 a 6 personas"
        public int? CapacidadMinima { get; set; }
        public int? CapacidadMaxima { get; set; }
        public DateTime? FechaEntrada { get; set; }
        public DateTime? FechaSalida { get; set; }
        public string? MensajeFechas { get; set; }

        // "" = todas, "Disponible" = disponibles, "Ocupada" = no disponibles
        public string? Estado { get; set; }

        // "Numero" (default), "Populares", "PrecioAsc", "PrecioDesc"
        public string OrdenarPor { get; set; } = "Numero";

        // ---- Datos para llenar los <select> de filtros ----
        public List<SelectListItem> Pisos { get; set; } = new();

        // ---- Resultado ----
        public List<HabitacionCardViewModel> Habitaciones { get; set; } = new();
    }
}
