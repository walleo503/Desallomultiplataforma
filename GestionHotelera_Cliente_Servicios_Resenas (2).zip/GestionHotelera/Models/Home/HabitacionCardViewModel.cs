using GestionHotelera.Models.Enums;

namespace GestionHotelera.Models.Home
{
    public class HabitacionCardViewModel
    {
        public int Id { get; set; }
        public string Numero { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public int Capacidad { get; set; }
        public int NumeroCamas { get; set; }
        public int Piso { get; set; }
        public decimal Precio { get; set; }
        public EstadoHabitacion Estado { get; set; }
        public string? ImagenUrl { get; set; }
        public bool EsPopular { get; set; }
    }
}
