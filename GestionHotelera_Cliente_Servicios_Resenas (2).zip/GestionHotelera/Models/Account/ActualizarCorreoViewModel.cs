using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Account
{
    public class ActualizarCorreoViewModel
    {
        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "Ingresa un correo válido.")]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Ingresa tu contraseña actual para confirmar el cambio.")]
        [DataType(DataType.Password)]
        public string PasswordActual { get; set; } = string.Empty;
    }
}
