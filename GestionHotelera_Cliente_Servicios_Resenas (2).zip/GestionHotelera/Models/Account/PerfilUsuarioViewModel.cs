namespace GestionHotelera.Models.Account
{
    public class PerfilUsuarioViewModel
    {
        public string Email { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        public string Apellido { get; set; } = string.Empty;
        public string TipoCuenta { get; set; } = string.Empty;
        public string? Dui { get; set; }
        public string? Telefono { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public string? Sexo { get; set; }
        public string? Cargo { get; set; }
        public string? Turno { get; set; }
        public string? Estado { get; set; }
    }
}
