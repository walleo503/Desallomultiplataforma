using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Account
{
    // Una cuenta ordinaria crea un huésped. Con la clave correcta se crea
    // una cuenta de administrador; el secretario se da de alta en Empleados.
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "El nombre es obligatorio.")]
        [MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es obligatorio.")]
        [MaxLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        [MaxLength(256)]
        public string Email { get; set; } = string.Empty;

        [MaxLength(15)]
        public string? DUI { get; set; }

        [MaxLength(20)]
        public string? Telefono { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [MinLength(8, ErrorMessage = "La contraseña debe tener al menos 8 caracteres.")]
        public string Password { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Las contraseñas no coinciden.")]
        public string ConfirmPassword { get; set; } = string.Empty;

        public bool EsAdministrador { get; set; }

        [DataType(DataType.Password)]
        [MaxLength(128)]
        public string? ClaveAdministrador { get; set; }
    }
}
