using System.ComponentModel.DataAnnotations;

namespace GestionHotelera.Models.Account
{
    public class LoginViewModel
    {
        [Required]
        [EmailAddress]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        public bool RememberMe { get; set; }
    }
}
