using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GestionHotelera.Models.Empleados
{
    public class CrearEmpleadoViewModel
    {
        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Date)]
        public DateTime? FechaNacimiento { get; set; }

        [MaxLength(20)]
        public string? Sexo { get; set; }

        [Required, MaxLength(15)]
        public string Dui { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        [MaxLength(256)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        [MinLength(8, ErrorMessage = "La contraseña debe tener al menos 8 caracteres.")]
        public string Password { get; set; } = string.Empty;

        // El cargo determina el rol interno: Administrador o Secretario.
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Selecciona un cargo.")]
        public int CargoId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Selecciona un turno.")]
        public int HorarioId { get; set; }

        public List<SelectListItem>? Cargos { get; set; }
        public List<SelectListItem>? Horarios { get; set; }
    }
}
