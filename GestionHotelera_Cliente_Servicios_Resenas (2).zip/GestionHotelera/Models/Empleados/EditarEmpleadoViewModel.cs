using System.ComponentModel.DataAnnotations;
using GestionHotelera.Models.Enums;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GestionHotelera.Models.Empleados
{
    public class EditarEmpleadoViewModel
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Nombre { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Apellido { get; set; } = string.Empty;

        [Required, DataType(DataType.Date)]
        public DateTime FechaNacimiento { get; set; }

        [MaxLength(20)]
        public string? Sexo { get; set; }

        [Required, MaxLength(15)]
        public string Dui { get; set; } = string.Empty;

        [Required, EmailAddress]
        [RegularExpression(@"(?i)^[^@\s]+@gmail\.com$", ErrorMessage = "Solo se permiten cuentas gmail.com.")]
        public string Email { get; set; } = string.Empty;

        [Range(1, int.MaxValue)]
        public int CargoId { get; set; }

        [Range(1, int.MaxValue)]
        public int HorarioId { get; set; }

        [Required]
        public EstadoEmpleado Estado { get; set; } = EstadoEmpleado.Activo;

        public List<SelectListItem> Cargos { get; set; } = new();
        public List<SelectListItem> Horarios { get; set; } = new();
    }
}
