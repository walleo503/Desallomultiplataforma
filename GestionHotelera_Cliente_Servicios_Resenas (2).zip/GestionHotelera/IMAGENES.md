# Imágenes del proyecto

El proyecto incorpora doce visuales nuevos de carácter ilustrativo en `wwwroot/images/`, convertidos a WebP para reducir el peso de descarga. Las tres imágenes PNG anteriores permanecen como alternativa para habitaciones creadas sin imagen propia.

## Asignación

| Archivo | Uso | Escena solicitada |
| --- | --- | --- |
| `hero-courtyard.webp` | Portada | Vestíbulo y patio abierto con vegetación, madera y agua. |
| `room-101.webp` | Habitación 101 | Dormitorio compacto, cama matrimonial y escritorio. |
| `room-102.webp` | Habitación 102 | Habitación doble azul con calle histórica. |
| `room-103.webp` | Habitación 103 | Dos camas, muros terracota y patio de ladrillo. |
| `room-201.webp` | Habitación 201 | Suite oscura con madera y vistas a la montaña. |
| `room-202.webp` | Habitación 202 | Dos camas, espacio extra para dormir y balcón. |
| `room-203.webp` | Habitación 203 | Dormitorio renovado, cama matrimonial y escritorio. |
| `room-301.webp` | Habitación 301 | Suite con sala oliva y vistas a la ciudad. |
| `room-302.webp` | Habitación 302 | Suite coral con dos áreas de descanso. |
| `space-terrace.webp` | Galería | Terraza de jardín con asientos y vegetación. |
| `space-breakfast.webp` | Galería y guía | Comedor luminoso abierto al patio. |
| `space-passage.webp` | Galería y acceso | Corredor de piedra hacia el jardín. |

## Criterio visual de los prompts

Fotografía arquitectónica editorial horizontal de un hotel boutique contemporáneo: escenas con variedad de paletas, estilos, disposición de camas y luz. Sin personas, rótulos, marcas ni marcas de agua. Los cinco visuales actualizados contrastan con las habitaciones claras anteriores mediante azul, terracota, madera oscura, verde oliva y coral.

Las imágenes son conceptuales y no acreditan instalaciones reales ni servicios incluidos. Sustitúyelas por fotografías verificadas antes de representar un establecimiento real. La semilla asocia `room-*.webp` a las habitaciones 101–302 solo si su campo `ImagenUrl` está vacío; conserva cualquier fotografía personalizada.
