using GestionHotelera.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestionHotelera.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20260928194000_AgregarDetalleEfectivoPago")]
    public class AgregarDetalleEfectivoPago : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "Cambio",
                table: "Pagos",
                type: "decimal(10,2)",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "MontoRecibido",
                table: "Pagos",
                type: "decimal(10,2)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(name: "Cambio", table: "Pagos");
            migrationBuilder.DropColumn(name: "MontoRecibido", table: "Pagos");
        }
    }
}
