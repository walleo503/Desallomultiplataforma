using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.StaticFiles;
using System.Threading.RateLimiting;
using GestionHotelera.Data;
using GestionHotelera.Models.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Comprobantes PDF y envío opcional por correo.
builder.Services.AddSingleton<GestionHotelera.Services.PaymentReceiptPdfService>();
builder.Services.AddScoped<GestionHotelera.Services.ReceiptEmailService>();

// ---------- Base de datos (MySQL vía XAMPP, con Pomelo) ----------
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Configura ConnectionStrings:DefaultConnection antes de iniciar.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// ---------- ASP.NET Core Identity ----------
builder.Services.AddIdentity<IdentityUser, IdentityRole>(options =>
    {
        options.Password.RequireNonAlphanumeric = false;
        options.Password.RequiredLength = 8;
        options.User.RequireUniqueEmail = true;
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.Lockout.AllowedForNewUsers = true;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

// Reduce los intentos de adivinar la clave de registro de administrador.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("registro", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            context.Connection.RemoteIpAddress?.ToString() ?? "sin-ip",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 5,
                Window = TimeSpan.FromMinutes(10),
                QueueLimit = 0,
                AutoReplenishment = true
            }));
});

// ---------- Roles + Policies + Permisos ----------
// Copia al usuario, en cada request, los permisos de su(s) rol(es).
builder.Services.AddScoped<IClaimsTransformation, PermissionClaimsTransformation>();

// Crea una Policy por cada permiso definido en Models/Authorization/Permisos.cs.
// Así, [Authorize(Policy = Permisos.HabitacionesCrear)] exige que el usuario
// tenga el Claim "Permission" = "Habitaciones.Crear" (heredado de su rol).
builder.Services.AddAuthorization(options =>
{
    foreach (var permiso in Permisos.Todos())
    {
        options.AddPolicy(permiso, policy => policy.RequireClaim("Permission", permiso));
    }
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
var imageTypes = new FileExtensionContentTypeProvider();
imageTypes.Mappings[".webp"] = "image/webp";
app.UseStaticFiles(new StaticFileOptions { ContentTypeProvider = imageTypes });

app.UseRouting();
app.UseRateLimiter();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// MigrateAsync crea la base y las tablas si faltan, y aplica solo las
// migraciones pendientes. Después se cargan los datos iniciales.
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    await context.Database.MigrateAsync();
    await DbSeeder.SeedAsync(scope.ServiceProvider);
}

app.Run();
