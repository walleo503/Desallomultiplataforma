# Gestión Hotelera — versión integrada Ámbar

Esta versión toma como base visual y funcional el proyecto `GestionHotelera(3)` y conserva las funciones agregadas en `GestionHotelera_Diseno_Aplicado`: búsqueda/alta de huéspedes desde una reserva y carga de imágenes por arrastrar y soltar.

## Requisitos

- Visual Studio 2022 con .NET 8.
- MySQL/MariaDB iniciado (por ejemplo XAMPP).
- Cadena por defecto: `Gestion_Hotelera`, `root`, sin contraseña, puerto 3306. Se puede cambiar en `appsettings.json`.

Abre `GestionHotelera.sln`, ejecuta **Compilar > Recompilar solución** y luego F5. `Program.cs` aplica automáticamente las migraciones pendientes y ejecuta el seeder sin borrar la información existente.

### Mismos datos en varios equipos

`Server=localhost` conecta cada instalación a la base MySQL de **esa misma computadora**. Si administración y recepción abren una copia de la aplicación en PCs distintas, pueden ver reservas, saldos e ingresos diferentes aunque ambos hayan iniciado sesión. En Operación, Historial e Ingresos se muestra la instancia, el servidor MySQL y la base utilizada para poder comparar su origen sin revelar contraseñas.

Para compartir los datos, abre la **misma aplicación alojada en un único servidor** desde los navegadores de ambos equipos. Si cada PC ejecuta su propia copia de la aplicación, configura en ambas `ConnectionStrings:DefaultConnection` (o la variable `ConnectionStrings__DefaultConnection`) apuntando a **la misma base MySQL accesible desde la red**, con los permisos y respaldo correspondientes. `localhost` en la PC de recepción no apunta a la PC de administración. Cambiar el servidor de conexión no migra automáticamente las reservas existentes: respalda y traslada los datos antes de cambiar la base si necesitas conservarlos.

## Diseño e imágenes

La interfaz completa usa el diseño Ámbar del proyecto de referencia: navegación, portada, catálogo, detalle de habitación, operación, habitaciones, equipo, ingresos, formularios, checkout y comprobante. Los estilos están en `wwwroot/css/design.css`.

Las imágenes locales de las habitaciones 101, 102, 103, 201, 202, 203, 301 y 302 están en `wwwroot/images`. Al iniciar, si una de esas habitaciones existe y no tiene `ImagenUrl`, el seeder le asigna su imagen local. Para nuevas habitaciones se puede arrastrar/subir JPG, PNG, WEBP o GIF (máximo 5 MB) o pegar una URL.

## Equipo

El formulario de empleados usa solamente **Cargo**: Administrador o Secretario. El cargo determina el rol y los permisos de Identity. Los turnos son:

- Mañana (6:00 a. m. - 12:00 p. m.)
- Tarde (12:00 p. m. - 6:00 p. m.)
- Noche (6:00 p. m. - 6:00 a. m.)

La fecha de nacimiento queda vacía al crear un empleado y el selector está limitado entre 1900 y hoy. Sexo es un menú con Hombre, Mujer y Prefiero no decir.

Desde Equipo se puede editar nombre, apellido, DUI, fecha de nacimiento, sexo, Gmail, cargo, turno y estado. Estados: Activo, Suspendido y Despedido. Suspendido/Despedido bloquean el acceso y dejan de recibir permisos. También se puede eliminar un empleado, excepto la propia cuenta activa o el único Administrador.

## Reservas

Administrador y Secretario pueden abrir una habitación y crear una reserva a nombre de un huésped. El huésped se busca por nombre, apellido, nombre completo o correo. Si no existe, se registra desde el mismo formulario y queda seleccionado automáticamente.

En **Operación** se puede:

- Editar una reserva confirmada (habitación, fechas y huéspedes).
- Hacer check-in cuando llega la fecha de entrada; la habitación pasa a `Ocupada`.
- Hacer check-out después del check-in; la reserva pasa a `Finalizada` y la habitación a `Limpieza`.
- Cancelar reservas confirmadas cuando no tienen pagos reales que deban revisarse.
- Eliminar únicamente reservas canceladas sin pagos reales; se eliminan también sus registros de prueba, para evitar destruir historial financiero.
- Registrar pagos manuales sin superar el saldo pendiente.
- Los pagos de prueba del checkout no reducen el saldo real: recepción puede registrar el cobro auténtico. Los comprobantes PDF e ingresos solo incluyen pagos reales.
- Consultar el historial completo, incluyendo quién hizo/gestionó la reserva.

El flujo de huésped existente se conserva: consulta de disponibilidad, checkout, pago de prueba, comprobante, Mis reservas y cancelación según las reglas existentes.

## Cuentas de una instalación nueva

En una base completamente nueva se crean una vez:

- Administrador: `administrador.hotel@gmail.com` / `Admin123!`
- Secretario: `secretario.hotel@gmail.com` / `Secretario123!`

No se recrean si después se eliminan. El registro y login mantienen el requisito de cuentas `gmail.com`.

## Nota sobre la base existente

No se agregó ninguna columna nueva para el estado laboral. Activo/Suspendido/Despedido se guarda como claim de ASP.NET Identity, por lo que no hace falta crear una migración adicional para esta integración. Las migraciones ya incluidas se siguen aplicando normalmente.

## Mi cuenta (Administrador, Secretario y Huésped)

Todos los usuarios autenticados tienen ahora el acceso **Mi cuenta** en la barra superior. Allí pueden:

- Ver sus datos principales.
- Cambiar el correo Gmail usado para iniciar sesión (confirma con la contraseña actual).
- Cambiar su contraseña (solicita contraseña actual, nueva y confirmación).

Los datos administrativos como cargo, turno, estado laboral, DUI o fecha de nacimiento se muestran, pero no se modifican desde Mi cuenta. Los datos de empleados continúan gestionándose desde **Equipo**.

## Pago en efectivo, cambio y comprobante PDF

En **Operación > Registrar pago**:

- Si el método es **Efectivo**, el campo representa el dinero recibido. Puede ser mayor que el saldo. Ejemplo: saldo `$650.00`, recibe `$700.00`, el sistema aplica `$650.00` y calcula `$50.00` de cambio.
- Si es **Tarjeta** o **Transferencia**, el monto no puede superar el saldo pendiente.
- Al guardar se crea un comprobante PDF y la pantalla intenta descargarlo automáticamente.
- El último comprobante real también puede descargarse nuevamente desde la reserva.
- El huésped puede descargar el PDF de sus pagos reales desde **Mis reservas**.

La migración `20260928194000_AgregarDetalleEfectivoPago` agrega a `Pagos` los campos `MontoRecibido` y `Cambio`. El proyecto ejecuta `Database.MigrateAsync()` al iniciar, por lo que la migración se aplica automáticamente al arrancar con MySQL disponible.

### Envío automático del PDF por Gmail

El envío está implementado pero desactivado hasta configurar una cuenta remitente. En `appsettings.json` existe:

```json
"Email": {
  "Enabled": false,
  "SmtpHost": "smtp.gmail.com",
  "SmtpPort": 587,
  "SenderEmail": "",
  "SenderName": "Ámbar Estancias",
  "AppPassword": ""
}
```

Para activarlo usa una cuenta Gmail del hotel y una **contraseña de aplicación de Google**, no la contraseña normal de la cuenta. Completa `SenderEmail` y `AppPassword`, y cambia `Enabled` a `true`. Al registrar un pago, el sistema adjunta el mismo PDF y lo envía al correo asociado a la cuenta del huésped. Si Gmail falla o no está configurado, el pago no se pierde: el PDF sigue disponible para descarga manual.

## Funciones añadidas para Cliente/Huésped

- Durante una estancia con **check-in realizado**, el huésped puede solicitar **Limpieza** o **Comida** desde **Mis reservas**, indicando detalles opcionales. La solicitud queda registrada con estado `Pendiente` y el huésped puede consultar su estado.
- Después de una estancia marcada como **Finalizada**, el huésped puede dejar **una reseña** de 1 a 5 estrellas y un comentario opcional. No se permite reseñar una reserva activa, futura o cancelada ni registrar más de una reseña por reserva.
- Estas funciones utilizan las tablas `SolicitudesServicio` y `Resenas` que ya formaban parte del modelo y de la migración inicial; no requieren una migración adicional.
