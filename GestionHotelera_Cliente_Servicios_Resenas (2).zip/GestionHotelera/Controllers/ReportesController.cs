using GestionHotelera.Data;
using GestionHotelera.Models.Authorization;
using GestionHotelera.Models.Reportes;
using GestionHotelera.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace GestionHotelera.Controllers
{
    [Authorize(Policy = Permisos.ReportesVerIngresos)]
    public class ReportesController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ReportesController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Ingresos(int? anio)
        {
            var year = anio.HasValue && anio.Value >= 2024 && anio.Value <= HotelClock.Today.Year
                ? anio.Value : HotelClock.Today.Year;
            var desde = new DateTime(year, 1, 1);
            var hasta = desde.AddYears(1);

            var agrupados = await PaymentAccounting.RealPayments(_context.Pagos.AsNoTracking())
                .Where(p => p.FechaPago >= desde && p.FechaPago < hasta)
                .GroupBy(p => p.FechaPago.Month)
                .Select(g => new { Mes = g.Key, Total = g.Sum(p => p.Monto), Pagos = g.Count() })
                .ToListAsync();

            var modelo = new ResumenIngresosViewModel
            {
                Anio = year,
                Total = agrupados.Sum(g => g.Total),
                CantidadPagos = agrupados.Sum(g => g.Pagos),
                Meses = Enumerable.Range(1, 12).Select(m => new IngresoMensual
                {
                    Numero = m,
                    Nombre = CultureInfo.GetCultureInfo("es-SV").DateTimeFormat.GetAbbreviatedMonthName(m),
                    Total = agrupados.FirstOrDefault(g => g.Mes == m)?.Total ?? 0,
                    Pagos = agrupados.FirstOrDefault(g => g.Mes == m)?.Pagos ?? 0
                }).ToList()
            };

            ViewBag.OrigenDatos = DatabaseLocation.Description(_context);
            return View(modelo);
        }
    }
}
