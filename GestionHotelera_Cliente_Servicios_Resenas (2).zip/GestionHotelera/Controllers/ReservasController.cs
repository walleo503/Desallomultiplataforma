using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Data;
using GestionHotelera.Data;
using GestionHotelera.Models.Authorization;
using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;
using GestionHotelera.Models.Reservas;
using GestionHotelera.Services;

namespace GestionHotelera.Controllers
{
    [Authorize]
    public class ReservasController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly PaymentReceiptPdfService _receiptPdf;
        private readonly ReceiptEmailService _receiptEmail;

        public ReservasController(
            ApplicationDbContext context,
            UserManager<IdentityUser> userManager,
            PaymentReceiptPdfService receiptPdf,
            ReceiptEmailService receiptEmail)
        {
            _context = context;
            _userManager = userManager;
            _receiptPdf = receiptPdf;
            _receiptEmail = receiptEmail;
        }

        // Flujo de cliente: conserva el checkout y pago de prueba existentes.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCrear)]
        public IActionResult Crear(ReservarHabitacionViewModel model) => RedirectToAction(nameof(Checkout),
            new { model.HabitacionId, fechaEntrada = model.FechaEntrada.ToString("yyyy-MM-dd"),
                fechaSalida = model.FechaSalida.ToString("yyyy-MM-dd"), model.CantidadHuespedes });

        // Búsqueda por nombre, apellido, nombre completo o correo para recepción/administración.
        [HttpGet]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> BuscarClientes(string? termino)
        {
            termino = termino?.Trim() ?? string.Empty;
            if (termino.Length < 2) return Json(Array.Empty<object>());

            var clientes = await (
                from cliente in _context.Clientes
                join usuario in _context.Users on cliente.AspNetUserId equals usuario.Id
                where cliente.Nombre.Contains(termino) || cliente.Apellido.Contains(termino) ||
                      (cliente.Nombre + " " + cliente.Apellido).Contains(termino) ||
                      (usuario.Email != null && usuario.Email.Contains(termino))
                orderby cliente.Nombre, cliente.Apellido
                select new
                {
                    id = cliente.Id,
                    nombre = cliente.Nombre + " " + cliente.Apellido,
                    email = usuario.Email ?? usuario.UserName ?? string.Empty,
                    dui = cliente.Dui ?? string.Empty,
                    telefono = cliente.Telefono ?? string.Empty
                }).Take(15).ToListAsync();
            return Json(clientes);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCrear)]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> CrearCliente(CrearClienteReservaViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var errores = ModelState.Values.SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage).Where(m => !string.IsNullOrWhiteSpace(m)).Distinct().ToArray();
                return BadRequest(new { ok = false, errores });
            }

            var email = model.Email.Trim().ToLowerInvariant();
            if (await _userManager.FindByEmailAsync(email) != null)
                return BadRequest(new { ok = false, errores = new[] { "Ya existe una cuenta registrada con ese correo." } });

            var dui = model.Dui.Trim();
            if (await _context.Clientes.AnyAsync(c => c.Dui == dui))
                return BadRequest(new { ok = false, errores = new[] { "Ya existe un cliente registrado con ese DUI." } });

            var usuario = new IdentityUser { UserName = email, Email = email, EmailConfirmed = true,
                PhoneNumber = string.IsNullOrWhiteSpace(model.Telefono) ? null : model.Telefono.Trim() };
            var resultadoUsuario = await _userManager.CreateAsync(usuario, model.Password);
            if (!resultadoUsuario.Succeeded)
                return BadRequest(new { ok = false, errores = resultadoUsuario.Errors.Select(e => e.Description).ToArray() });

            var resultadoRol = await _userManager.AddToRoleAsync(usuario, DbSeeder.RolCliente);
            if (!resultadoRol.Succeeded)
            {
                await _userManager.DeleteAsync(usuario);
                return BadRequest(new { ok = false, errores = resultadoRol.Errors.Select(e => e.Description).ToArray() });
            }

            var cliente = new Cliente { AspNetUserId = usuario.Id, Nombre = model.Nombre.Trim(),
                Apellido = model.Apellido.Trim(), Dui = dui,
                Telefono = string.IsNullOrWhiteSpace(model.Telefono) ? null : model.Telefono.Trim() };
            try
            {
                _context.Clientes.Add(cliente);
                await _context.SaveChangesAsync();
            }
            catch
            {
                await _userManager.DeleteAsync(usuario);
                throw;
            }

            return Json(new { ok = true, cliente = new { id = cliente.Id,
                nombre = $"{cliente.Nombre} {cliente.Apellido}", email, dui = cliente.Dui ?? string.Empty,
                telefono = cliente.Telefono ?? string.Empty } });
        }

        // Flujo del personal: reserva directamente a nombre de un huésped, sin alterar el checkout del cliente.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCrear)]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> CrearGestion(ReservarHabitacionViewModel model)
        {
            if (!model.ClienteId.HasValue)
                return VolverADetalle(model, "Selecciona el cliente para quien se realizará la reserva.");

            var cliente = await _context.Clientes.FindAsync(model.ClienteId.Value);
            var habitacion = await _context.Habitaciones.FindAsync(model.HabitacionId);
            if (cliente == null || habitacion == null) return NotFound();

            var entrada = model.FechaEntrada.Date;
            var salida = model.FechaSalida.Date;
            if (entrada < HotelClock.Today || salida <= entrada || salida > HotelClock.Today.AddYears(2))
                return VolverADetalle(model, "Revisa las fechas de entrada y salida.");
            if (model.CantidadHuespedes < 1 || model.CantidadHuespedes > habitacion.Capacidad)
                return VolverADetalle(model, $"La habitación admite entre 1 y {habitacion.Capacidad} huésped(es).");
            if (habitacion.Estado == EstadoHabitacion.Mantenimiento)
                return VolverADetalle(model, "No se puede reservar una habitación que está en mantenimiento.");
            if (await HayCruceAsync(habitacion.Id, entrada, salida))
                return VolverADetalle(model, "La habitación ya tiene una reserva que se cruza con esas fechas.");

            var usuario = await _userManager.GetUserAsync(User);
            var empleadoId = usuario == null ? (int?)null : await _context.Empleados
                .Where(e => e.AspNetUserId == usuario.Id).Select(e => (int?)e.Id).FirstOrDefaultAsync();
            var noches = (salida - entrada).Days;
            var reserva = new Reserva
            {
                HabitacionId = habitacion.Id, ClienteId = cliente.Id, EmpleadoId = empleadoId,
                FechaEntrada = entrada, FechaSalida = salida, FechaReserva = HotelClock.Now,
                CantidadHuespedes = model.CantidadHuespedes, Total = noches * habitacion.Precio,
                EstadoReserva = EstadoReserva.Confirmada
            };
            _context.Reservas.Add(reserva);
            await _context.SaveChangesAsync();
            TempData["Exito"] = $"Reserva #{reserva.Id} creada para {cliente.Nombre} {cliente.Apellido}.";
            return RedirectToAction(nameof(Gestion));
        }

        [HttpGet]
        [Authorize(Policy = Permisos.ReservasCrear)]
        public async Task<IActionResult> Checkout(int habitacionId, DateTime fechaEntrada, DateTime fechaSalida, int cantidadHuespedes)
        {
            if (await ObtenerClienteIdAsync() == 0) return Forbid();
            var model = new CheckoutViewModel { HabitacionId = habitacionId, FechaEntrada = fechaEntrada,
                FechaSalida = fechaSalida, CantidadHuespedes = cantidadHuespedes, CorreoHuesped = User.Identity?.Name };
            var error = await PrepararCheckoutAsync(model);
            if (error != null) return VolverADetalle(model, error);
            model.PrecioVisto = model.Total;
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCrear)]
        public async Task<IActionResult> Pagar(CheckoutViewModel model)
        {
            var clienteId = await ObtenerClienteIdAsync();
            if (clienteId == 0) return Forbid();
            var error = await PrepararCheckoutAsync(model);
            if (error != null) return VolverADetalle(model, error);
            if (model.PrecioVisto != model.Total)
            {
                model.PrecioVisto = model.Total;
                ModelState.AddModelError(string.Empty, "La tarifa cambió. Revisa el nuevo total antes de volver a intentar.");
                return View(nameof(Checkout), model);
            }
            if (!ModelState.IsValid) return View(nameof(Checkout), model);
            if (model.TarjetaPrueba == "rechazo")
            {
                ModelState.AddModelError(string.Empty, "El pago de prueba fue rechazado. Elige otra tarjeta para reintentarlo; no se creó ninguna reserva.");
                return View(nameof(Checkout), model);
            }

            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
            var habitacion = (await _context.Habitaciones
                .FromSqlInterpolated($"SELECT * FROM Habitaciones WHERE Id = {model.HabitacionId} FOR UPDATE")
                .ToListAsync()).SingleOrDefault();
            if (habitacion == null) return NotFound();
            if (habitacion.Precio != model.PrecioNoche)
                return VolverADetalle(model, "La tarifa se actualizó mientras completabas el pago. Revisa el nuevo importe.");
            if (habitacion.Estado != EstadoHabitacion.Disponible || model.CantidadHuespedes > habitacion.Capacidad ||
                await HayCruceAsync(model.HabitacionId, model.FechaEntrada.Date, model.FechaSalida.Date))
                return VolverADetalle(model, "La disponibilidad cambió mientras completabas el pago. Elige otras fechas.");

            var reserva = new Reserva
            {
                HabitacionId = habitacion.Id, ClienteId = clienteId,
                FechaEntrada = model.FechaEntrada.Date, FechaSalida = model.FechaSalida.Date,
                FechaReserva = HotelClock.Now, CantidadHuespedes = model.CantidadHuespedes,
                Total = (model.FechaSalida.Date - model.FechaEntrada.Date).Days * habitacion.Precio,
                EstadoReserva = EstadoReserva.Confirmada
            };
            reserva.Pagos.Add(new Pago { Monto = reserva.Total, FechaPago = HotelClock.Now,
                MetodoPago = model.TarjetaPrueba == "visa" ? "Prueba Visa 4242" : "Prueba Mastercard 4444" });
            _context.Reservas.Add(reserva);
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();
            return RedirectToAction(nameof(Comprobante), new { id = reserva.Id });
        }

        [HttpGet]
        [Authorize(Policy = Permisos.ReservasVerPropias)]
        public async Task<IActionResult> Comprobante(int id)
        {
            var clienteId = await ObtenerClienteIdAsync();
            if (clienteId == 0) return Forbid();
            var reserva = await _context.Reservas.AsNoTracking().Include(r => r.Habitacion).Include(r => r.Pagos)
                .FirstOrDefaultAsync(r => r.Id == id && r.ClienteId == clienteId && r.Pagos.Any(p => p.MetodoPago.StartsWith("Prueba ")));
            return reserva == null ? NotFound() : View(reserva);
        }

        private async Task<int> ObtenerClienteIdAsync()
        {
            var usuario = await _userManager.GetUserAsync(User);
            return usuario == null ? 0 : await _context.Clientes.Where(c => c.AspNetUserId == usuario.Id)
                .Select(c => c.Id).FirstOrDefaultAsync();
        }

        private async Task<string?> PrepararCheckoutAsync(CheckoutViewModel model)
        {
            var habitacion = await _context.Habitaciones.AsNoTracking().FirstOrDefaultAsync(h => h.Id == model.HabitacionId);
            if (habitacion == null) return "La habitación ya no está disponible.";
            var entrada = model.FechaEntrada.Date;
            var salida = model.FechaSalida.Date;
            if (entrada < HotelClock.Today || salida <= entrada || salida > HotelClock.Today.AddYears(2) ||
                model.CantidadHuespedes < 1 || model.CantidadHuespedes > habitacion.Capacidad)
                return "Revisa las fechas y la cantidad de huéspedes antes de continuar.";
            if (habitacion.Estado != EstadoHabitacion.Disponible || await HayCruceAsync(model.HabitacionId, entrada, salida))
                return "La habitación no está disponible para esas fechas. Elige otro período.";
            model.NumeroHabitacion = habitacion.Numero;
            model.TipoHabitacion = habitacion.Tipo;
            model.ImagenUrl = habitacion.ImagenUrl;
            model.PrecioNoche = habitacion.Precio;
            model.Noches = (salida - entrada).Days;
            model.Total = model.Noches * habitacion.Precio;
            model.CorreoHuesped = User.Identity?.Name;
            return null;
        }

        private Task<bool> HayCruceAsync(int habitacionId, DateTime entrada, DateTime salida, int? excluirReservaId = null) =>
            _context.Reservas.AnyAsync(r => r.HabitacionId == habitacionId &&
                (!excluirReservaId.HasValue || r.Id != excluirReservaId.Value) &&
                r.EstadoReserva != EstadoReserva.Cancelada && r.EstadoReserva != EstadoReserva.Finalizada &&
                r.FechaEntrada < salida && r.FechaSalida > entrada);

        private IActionResult VolverADetalle(ReservarHabitacionViewModel model, string error)
        {
            TempData["Error"] = error;
            return RedirectToAction("Detalle", "Habitaciones", new { id = model.HabitacionId,
                fechaEntrada = model.FechaEntrada == default ? null : model.FechaEntrada.ToString("yyyy-MM-dd"),
                fechaSalida = model.FechaSalida == default ? null : model.FechaSalida.ToString("yyyy-MM-dd"),
                cantidadHuespedes = model.CantidadHuespedes });
        }

        [Authorize(Policy = Permisos.ReservasVerPropias)]
        public async Task<IActionResult> MisReservas()
        {
            var usuario = await _userManager.GetUserAsync(User);
            var clienteId = usuario == null ? 0 : await _context.Clientes.Where(c => c.AspNetUserId == usuario.Id)
                .Select(c => c.Id).FirstOrDefaultAsync();
            var reservas = clienteId == 0 ? new List<Reserva>() : await _context.Reservas.AsNoTracking()
                .Where(r => r.ClienteId == clienteId)
                .Include(r => r.Habitacion)
                .Include(r => r.Pagos)
                .Include(r => r.Solicitudes)
                .Include(r => r.Resena)
                .AsSplitQuery()
                .OrderByDescending(r => r.FechaReserva).ToListAsync();
            return View(reservas);
        }

        // El huésped puede solicitar limpieza o comida únicamente durante una estancia activa.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.SolicitudesCrear)]
        public async Task<IActionResult> SolicitarServicio(int reservaId, string tipoServicio, string? descripcion)
        {
            var clienteId = await ObtenerClienteIdAsync();
            if (clienteId == 0) return Forbid();

            var reserva = await _context.Reservas
                .FirstOrDefaultAsync(r => r.Id == reservaId && r.ClienteId == clienteId);
            if (reserva == null) return NotFound();

            if (reserva.EstadoReserva != EstadoReserva.CheckInRealizado)
            {
                TempData["Error"] = "Los servicios de limpieza o comida solo pueden solicitarse durante una estancia con check-in realizado.";
                return RedirectToAction(nameof(MisReservas));
            }

            var tipo = tipoServicio?.Trim() ?? string.Empty;
            if (tipo.Equals("Limpieza", StringComparison.OrdinalIgnoreCase)) tipo = "Limpieza";
            else if (tipo.Equals("Comida", StringComparison.OrdinalIgnoreCase)) tipo = "Comida";
            else
            {
                TempData["Error"] = "Selecciona un servicio válido: Limpieza o Comida.";
                return RedirectToAction(nameof(MisReservas));
            }

            descripcion = descripcion?.Trim();
            if (!string.IsNullOrEmpty(descripcion) && descripcion.Length > 255)
            {
                TempData["Error"] = "La descripción del servicio no puede superar los 255 caracteres.";
                return RedirectToAction(nameof(MisReservas));
            }

            _context.SolicitudesServicio.Add(new SolicitudServicio
            {
                ReservaId = reserva.Id,
                TipoServicio = tipo,
                Descripcion = string.IsNullOrWhiteSpace(descripcion) ? null : descripcion,
                Estado = EstadoSolicitud.Pendiente,
                FechaSolicitud = HotelClock.Now
            });
            await _context.SaveChangesAsync();

            TempData["Exito"] = $"Solicitud de {tipo.ToLowerInvariant()} enviada a recepción.";
            return RedirectToAction(nameof(MisReservas));
        }

        // Una reserva finalizada admite una única reseña del huésped propietario de la reserva.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ResenasCrear)]
        public async Task<IActionResult> CrearResena(int reservaId, int calificacion, string? comentario)
        {
            var clienteId = await ObtenerClienteIdAsync();
            if (clienteId == 0) return Forbid();

            var reserva = await _context.Reservas
                .Include(r => r.Resena)
                .FirstOrDefaultAsync(r => r.Id == reservaId && r.ClienteId == clienteId);
            if (reserva == null) return NotFound();

            if (reserva.EstadoReserva != EstadoReserva.Finalizada)
            {
                TempData["Error"] = "Puedes dejar una reseña únicamente después de finalizar tu estadía.";
                return RedirectToAction(nameof(MisReservas));
            }

            if (reserva.Resena != null)
            {
                TempData["Error"] = "Esta estadía ya tiene una reseña registrada.";
                return RedirectToAction(nameof(MisReservas));
            }

            if (calificacion < 1 || calificacion > 5)
            {
                TempData["Error"] = "La calificación debe estar entre 1 y 5 estrellas.";
                return RedirectToAction(nameof(MisReservas));
            }

            comentario = comentario?.Trim();
            if (!string.IsNullOrEmpty(comentario) && comentario.Length > 500)
            {
                TempData["Error"] = "El comentario de la reseña no puede superar los 500 caracteres.";
                return RedirectToAction(nameof(MisReservas));
            }

            _context.Resenas.Add(new Resena
            {
                ReservaId = reserva.Id,
                Calificacion = calificacion,
                Comentario = string.IsNullOrWhiteSpace(comentario) ? null : comentario,
                Fecha = HotelClock.Now
            });
            await _context.SaveChangesAsync();

            TempData["Exito"] = "Gracias. Tu reseña fue registrada correctamente.";
            return RedirectToAction(nameof(MisReservas));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCancelar)]
        public async Task<IActionResult> Cancelar(int id)
        {
            var usuario = await _userManager.GetUserAsync(User);
            var clienteId = usuario == null ? 0 : await _context.Clientes.Where(c => c.AspNetUserId == usuario.Id)
                .Select(c => c.Id).FirstOrDefaultAsync();
            if (clienteId == 0) return Forbid();

            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
            var reserva = (await _context.Reservas.FromSqlInterpolated($"SELECT * FROM Reservas WHERE Id = {id} FOR UPDATE")
                .ToListAsync()).SingleOrDefault();
            if (reserva == null || reserva.ClienteId != clienteId) return NotFound();
            if (reserva.EstadoReserva != EstadoReserva.Confirmada || reserva.FechaEntrada.Date <= HotelClock.Today)
            {
                TempData["Error"] = "Solo puedes cancelar una reserva confirmada antes del día de entrada.";
                return RedirectToAction(nameof(MisReservas));
            }
            if (await _context.Pagos.AnyAsync(p => p.ReservaId == id && !p.MetodoPago.StartsWith("Prueba ")))
            {
                TempData["Error"] = "Esta reserva tiene pagos registrados. Contacta a recepción para tramitarla.";
                return RedirectToAction(nameof(MisReservas));
            }
            reserva.EstadoReserva = EstadoReserva.Cancelada;
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();
            TempData["Exito"] = "Tu reserva fue cancelada.";
            return RedirectToAction(nameof(MisReservas));
        }

        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> Gestion(EstadoReserva? estado)
        {
            var query = _context.Reservas.AsNoTracking()
                .Include(r => r.Habitacion).Include(r => r.Cliente).Include(r => r.Empleado).ThenInclude(e => e!.Cargo)
                .Include(r => r.Pagos).AsQueryable();
            if (estado.HasValue && Enum.IsDefined(estado.Value)) query = query.Where(r => r.EstadoReserva == estado.Value);
            ViewBag.Estado = estado;
            ViewBag.OrigenDatos = DatabaseLocation.Description(_context);
            return View(await query.OrderByDescending(r => r.FechaEntrada).Take(200).ToListAsync());
        }

        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> Historial(int? habitacionId = null)
        {
            var query = _context.Reservas.AsNoTracking().Include(r => r.Habitacion).Include(r => r.Cliente)
                .Include(r => r.Empleado).ThenInclude(e => e!.Cargo).Include(r => r.Pagos).AsQueryable();
            if (habitacionId.HasValue) query = query.Where(r => r.HabitacionId == habitacionId.Value);
            ViewBag.HabitacionId = habitacionId;
            ViewBag.OrigenDatos = DatabaseLocation.Description(_context);
            return View(await query.OrderByDescending(r => r.FechaReserva).ToListAsync());
        }

        [HttpGet]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> Editar(int id)
        {
            var reserva = await _context.Reservas.AsNoTracking().Include(r => r.Cliente).FirstOrDefaultAsync(r => r.Id == id);
            if (reserva == null) return NotFound();
            if (reserva.EstadoReserva != EstadoReserva.Confirmada)
            {
                TempData["Error"] = "Solo las reservas confirmadas pueden editarse.";
                return RedirectToAction(nameof(Gestion));
            }
            var model = new EditarReservaViewModel
            {
                Id = reserva.Id, HabitacionId = reserva.HabitacionId,
                ClienteNombre = $"{reserva.Cliente?.Nombre} {reserva.Cliente?.Apellido}".Trim(),
                FechaEntrada = reserva.FechaEntrada, FechaSalida = reserva.FechaSalida,
                CantidadHuespedes = reserva.CantidadHuespedes
            };
            await CargarHabitacionesAsync(model);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> Editar(int id, EditarReservaViewModel model)
        {
            if (id != model.Id) return BadRequest();
            var reserva = await _context.Reservas.Include(r => r.Pagos).FirstOrDefaultAsync(r => r.Id == id);
            if (reserva == null) return NotFound();
            if (reserva.EstadoReserva != EstadoReserva.Confirmada)
            {
                TempData["Error"] = "Solo las reservas confirmadas pueden editarse.";
                return RedirectToAction(nameof(Gestion));
            }

            var habitacion = await _context.Habitaciones.FindAsync(model.HabitacionId);
            if (habitacion == null) ModelState.AddModelError(nameof(model.HabitacionId), "Selecciona una habitación válida.");
            var entrada = model.FechaEntrada.Date;
            var salida = model.FechaSalida.Date;
            if (entrada < HotelClock.Today || salida <= entrada || salida > HotelClock.Today.AddYears(2))
                ModelState.AddModelError(nameof(model.FechaSalida), "La salida debe ser posterior a la entrada y las fechas no pueden estar en el pasado.");
            if (habitacion != null && (model.CantidadHuespedes < 1 || model.CantidadHuespedes > habitacion.Capacidad))
                ModelState.AddModelError(nameof(model.CantidadHuespedes), $"La habitación admite hasta {habitacion.Capacidad} huéspedes.");
            if (habitacion?.Estado == EstadoHabitacion.Mantenimiento)
                ModelState.AddModelError(nameof(model.HabitacionId), "La habitación está en mantenimiento.");
            if (habitacion != null && await HayCruceAsync(habitacion.Id, entrada, salida, reserva.Id))
                ModelState.AddModelError(nameof(model.FechaEntrada), "La habitación ya tiene otra reserva en esas fechas.");

            if (habitacion != null)
            {
                var nuevoTotal = Math.Max(0, (salida - entrada).Days) * habitacion.Precio;
                var pagado = PaymentAccounting.RealPaid(reserva.Pagos);
                if (pagado > nuevoTotal)
                    ModelState.AddModelError(string.Empty, "No se puede reducir el total por debajo del monto ya pagado.");
            }

            if (!ModelState.IsValid)
            {
                var cliente = await _context.Clientes.FindAsync(reserva.ClienteId);
                model.ClienteNombre = cliente == null ? "Huésped" : $"{cliente.Nombre} {cliente.Apellido}";
                await CargarHabitacionesAsync(model);
                return View(model);
            }

            reserva.HabitacionId = model.HabitacionId;
            reserva.FechaEntrada = entrada;
            reserva.FechaSalida = salida;
            reserva.CantidadHuespedes = model.CantidadHuespedes;
            reserva.Total = (salida - entrada).Days * habitacion!.Precio;
            await _context.SaveChangesAsync();
            TempData["Exito"] = $"Reserva #{reserva.Id} actualizada.";
            return RedirectToAction(nameof(Gestion));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> CancelarGestion(int id)
        {
            var reserva = await _context.Reservas.Include(r => r.Pagos).FirstOrDefaultAsync(r => r.Id == id);
            if (reserva == null) return NotFound();
            if (reserva.EstadoReserva != EstadoReserva.Confirmada)
            {
                TempData["Error"] = "Solo una reserva confirmada puede cancelarse desde recepción.";
                return RedirectToAction(nameof(Gestion));
            }
            if (reserva.Pagos.Any(p => !p.MetodoPago.StartsWith("Prueba ")))
            {
                TempData["Error"] = "La reserva tiene pagos reales registrados. Revisa el cobro antes de cancelarla.";
                return RedirectToAction(nameof(Gestion));
            }
            reserva.EstadoReserva = EstadoReserva.Cancelada;
            await _context.SaveChangesAsync();
            TempData["Exito"] = $"Reserva #{id} cancelada.";
            return RedirectToAction(nameof(Gestion));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasVerTodas)]
        public async Task<IActionResult> EliminarGestion(int id)
        {
            var reserva = await _context.Reservas.Include(r => r.Pagos).FirstOrDefaultAsync(r => r.Id == id);
            if (reserva == null) return NotFound();
            if (reserva.EstadoReserva != EstadoReserva.Cancelada || reserva.Pagos.Any(p => !PaymentAccounting.IsTest(p)))
            {
                TempData["Error"] = "Por seguridad, solo se pueden eliminar reservas canceladas sin pagos reales.";
                return RedirectToAction(nameof(Gestion));
            }
            // Los pagos de prueba pertenecen a la reserva y deben borrarse antes
            // para respetar la integridad referencial de Pagos.ReservaId.
            _context.Pagos.RemoveRange(reserva.Pagos);
            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();
            TempData["Exito"] = $"Reserva #{id} eliminada.";
            return RedirectToAction(nameof(Gestion));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCheckIn)]
        public async Task<IActionResult> CheckIn(int id) => await CambiarEstadoAsync(id, EstadoReserva.Confirmada,
            EstadoReserva.CheckInRealizado, "Entrada registrada.");

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.ReservasCheckOut)]
        public async Task<IActionResult> CheckOut(int id) => await CambiarEstadoAsync(id, EstadoReserva.CheckInRealizado,
            EstadoReserva.Finalizada, "Salida registrada.");

        private async Task<IActionResult> CambiarEstadoAsync(int id, EstadoReserva anterior, EstadoReserva nuevo, string mensaje)
        {
            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
            var reserva = (await _context.Reservas.FromSqlInterpolated($"SELECT * FROM Reservas WHERE Id = {id} FOR UPDATE")
                .ToListAsync()).SingleOrDefault();
            if (reserva == null) return NotFound();
            var habitacion = await _context.Habitaciones.FindAsync(reserva.HabitacionId);
            if (habitacion == null) return NotFound();

            if (reserva.EstadoReserva != anterior || (nuevo == EstadoReserva.CheckInRealizado &&
                (HotelClock.Today < reserva.FechaEntrada.Date || HotelClock.Today >= reserva.FechaSalida.Date)))
            {
                TempData["Error"] = "La reserva no admite esa operación en su estado o fecha actual.";
                return RedirectToAction(nameof(Gestion));
            }

            if (nuevo == EstadoReserva.CheckInRealizado && habitacion.Estado != EstadoHabitacion.Disponible)
            {
                TempData["Error"] = $"No se puede hacer check-in: la habitación está {habitacion.Estado}. Debe estar Disponible.";
                return RedirectToAction(nameof(Gestion));
            }

            reserva.EstadoReserva = nuevo;
            if (nuevo == EstadoReserva.CheckInRealizado) habitacion.Estado = EstadoHabitacion.Ocupada;
            if (nuevo == EstadoReserva.Finalizada) habitacion.Estado = EstadoHabitacion.Limpieza;
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();
            TempData["Exito"] = mensaje + (nuevo == EstadoReserva.Finalizada ? " La habitación pasó a Limpieza." : " La habitación pasó a Ocupada.");
            return RedirectToAction(nameof(Gestion));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.PagosRegistrar)]
        public async Task<IActionResult> RegistrarPago(int id, decimal monto, string metodoPago)
        {
            var metodosValidos = new[] { "Efectivo", "Tarjeta", "Transferencia" };
            if (monto <= 0 || string.IsNullOrWhiteSpace(metodoPago) || !metodosValidos.Contains(metodoPago))
            {
                TempData["Error"] = "Indica un monto positivo y un método de pago válido.";
                return RedirectToAction(nameof(Gestion));
            }

            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
            var reserva = (await _context.Reservas.FromSqlInterpolated($"SELECT * FROM Reservas WHERE Id = {id} FOR UPDATE")
                .ToListAsync()).SingleOrDefault();
            if (reserva == null) return NotFound();
            if (reserva.EstadoReserva == EstadoReserva.Cancelada)
            {
                TempData["Error"] = "No se pueden registrar pagos a reservas canceladas.";
                return RedirectToAction(nameof(Gestion));
            }

            var pagado = await PaymentAccounting.RealPayments(_context.Pagos)
                .Where(p => p.ReservaId == id)
                .SumAsync(p => (decimal?)p.Monto) ?? 0;
            var saldo = Math.Max(0, reserva.Total - pagado);
            if (saldo <= 0)
            {
                TempData["Error"] = "Esta reserva ya está pagada por completo.";
                return RedirectToAction(nameof(Gestion));
            }

            decimal montoAplicado;
            decimal montoRecibido;
            decimal cambio;

            if (metodoPago == "Efectivo")
            {
                // El efectivo recibido puede superar el saldo. Solo se registra como pago
                // lo que corresponde a la reserva y la diferencia se devuelve como cambio.
                montoRecibido = monto;
                montoAplicado = Math.Min(montoRecibido, saldo);
                cambio = Math.Max(0, montoRecibido - saldo);
            }
            else
            {
                if (monto > saldo)
                {
                    TempData["Error"] = $"El cobro no puede exceder el saldo pendiente de ${saldo:0.00}.";
                    return RedirectToAction(nameof(Gestion));
                }
                montoRecibido = monto;
                montoAplicado = monto;
                cambio = 0;
            }

            var pago = new Pago
            {
                ReservaId = id,
                Monto = montoAplicado,
                MontoRecibido = montoRecibido,
                Cambio = cambio,
                MetodoPago = metodoPago,
                FechaPago = HotelClock.Now
            };
            _context.Pagos.Add(pago);
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            // El correo es opcional: el PDF siempre queda disponible para descarga.
            var reservaComprobante = await CargarReservaComprobanteAsync(id);
            var correo = reservaComprobante == null ? string.Empty : await ObtenerCorreoClienteAsync(reservaComprobante.Cliente);
            var correoEnviado = false;
            if (reservaComprobante != null)
            {
                var pdf = _receiptPdf.Crear(reservaComprobante, pago, correo);
                correoEnviado = await _receiptEmail.EnviarComprobanteAsync(
                    correo,
                    $"{reservaComprobante.Cliente?.Nombre} {reservaComprobante.Cliente?.Apellido}".Trim(),
                    reservaComprobante.Id,
                    pdf);
            }

            TempData["CorreoComprobanteEnviado"] = correoEnviado ? "1" : "0";
            TempData["Exito"] = cambio > 0
                ? $"Pago registrado. Cambio a entregar: ${cambio:0.00}."
                : "Pago registrado correctamente.";
            return RedirectToAction(nameof(PagoConfirmado), new { pagoId = pago.Id });
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> PagoConfirmado(int pagoId)
        {
            var pago = await _context.Pagos.AsNoTracking().FirstOrDefaultAsync(p => p.Id == pagoId);
            if (pago == null || PaymentAccounting.IsTest(pago)) return NotFound();
            var reserva = await CargarReservaComprobanteAsync(pago.ReservaId);
            if (reserva == null || !await PuedeVerComprobanteAsync(reserva)) return Forbid();

            var correo = await ObtenerCorreoClienteAsync(reserva.Cliente);
            var totalPagado = PaymentAccounting.RealPaid(reserva.Pagos);
            var model = new PagoConfirmadoViewModel
            {
                PagoId = pago.Id,
                ReservaId = reserva.Id,
                Cliente = $"{reserva.Cliente?.Nombre} {reserva.Cliente?.Apellido}".Trim(),
                CorreoCliente = correo,
                Habitacion = $"{reserva.Habitacion?.Numero} — {reserva.Habitacion?.Tipo}",
                MetodoPago = pago.MetodoPago,
                FechaPago = pago.FechaPago,
                TotalReserva = reserva.Total,
                MontoAplicado = pago.Monto,
                MontoRecibido = pago.MontoRecibido ?? pago.Monto,
                Cambio = pago.Cambio ?? 0,
                TotalPagado = totalPagado,
                SaldoRestante = Math.Max(0, reserva.Total - totalPagado),
                CorreoEnviado = TempData["CorreoComprobanteEnviado"]?.ToString() == "1",
                CorreoAutomaticoConfigurado = _receiptEmail.EstaConfigurado
            };
            return View(model);
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> DescargarComprobantePago(int pagoId)
        {
            var pago = await _context.Pagos.AsNoTracking().FirstOrDefaultAsync(p => p.Id == pagoId);
            if (pago == null || PaymentAccounting.IsTest(pago)) return NotFound();
            var reserva = await CargarReservaComprobanteAsync(pago.ReservaId);
            if (reserva == null || !await PuedeVerComprobanteAsync(reserva)) return Forbid();

            var correo = await ObtenerCorreoClienteAsync(reserva.Cliente);
            var pdf = _receiptPdf.Crear(reserva, pago, correo);
            return File(pdf, "application/pdf", $"comprobante-reserva-{reserva.Id}-pago-{pago.Id}.pdf");
        }

        private async Task<Reserva?> CargarReservaComprobanteAsync(int reservaId) =>
            await _context.Reservas.AsNoTracking()
                .Include(r => r.Cliente)
                .Include(r => r.Habitacion)
                .Include(r => r.Pagos)
                .FirstOrDefaultAsync(r => r.Id == reservaId);

        private async Task<string> ObtenerCorreoClienteAsync(Cliente? cliente)
        {
            if (cliente == null || string.IsNullOrWhiteSpace(cliente.AspNetUserId)) return string.Empty;
            return await _context.Users.Where(u => u.Id == cliente.AspNetUserId)
                .Select(u => u.Email ?? u.UserName ?? string.Empty).FirstOrDefaultAsync() ?? string.Empty;
        }

        private async Task<bool> PuedeVerComprobanteAsync(Reserva reserva)
        {
            if (User.IsInRole(DbSeeder.RolAdministrador) || User.IsInRole(DbSeeder.RolSecretario)) return true;
            var usuario = await _userManager.GetUserAsync(User);
            return usuario != null && reserva.Cliente?.AspNetUserId == usuario.Id;
        }

        private async Task CargarHabitacionesAsync(EditarReservaViewModel model)
        {
            model.Habitaciones = await _context.Habitaciones.AsNoTracking().OrderBy(h => h.Piso).ThenBy(h => h.Numero)
                .Select(h => new SelectListItem($"{h.Numero} — {h.Tipo} · {h.Capacidad} pers. · {h.Estado}", h.Id.ToString()))
                .ToListAsync();
        }
    }
}
