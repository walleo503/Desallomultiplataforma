using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using GestionHotelera.Data;
using GestionHotelera.Models.Account;
using GestionHotelera.Models.Entidades;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace GestionHotelera.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AccountController(
            UserManager<IdentityUser> userManager,
            SignInManager<IdentityUser> signInManager,
            ApplicationDbContext context,
            IConfiguration configuration)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _context = context;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Register(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("registro")]
        public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            model.Email = model.Email?.Trim() ?? string.Empty;
            model.Nombre = model.Nombre?.Trim() ?? string.Empty;
            model.Apellido = model.Apellido?.Trim() ?? string.Empty;
            model.DUI = model.DUI?.Trim();

            if (model.EsAdministrador)
            {
                if (string.IsNullOrWhiteSpace(_configuration["AdminRegistration:Secret"]))
                {
                    ModelState.AddModelError(nameof(model.ClaveAdministrador),
                        "El registro de administradores no está configurado.");
                }
                else if (!ClaveAdministradorValida(model.ClaveAdministrador))
                {
                    ModelState.AddModelError(nameof(model.ClaveAdministrador),
                        "Clave de administrador incorrecta.");
                }
            }
            else
            {
                if (string.IsNullOrWhiteSpace(model.DUI))
                    ModelState.AddModelError(nameof(model.DUI), "El DUI es obligatorio para huéspedes.");

                if (!string.IsNullOrWhiteSpace(model.ClaveAdministrador))
                    ModelState.AddModelError(nameof(model.ClaveAdministrador),
                        "Selecciona la opción de administrador para utilizar la clave.");

                if (!string.IsNullOrWhiteSpace(model.DUI) &&
                    await _context.Clientes.AnyAsync(c => c.Dui == model.DUI))
                    ModelState.AddModelError(nameof(model.DUI), "Este DUI ya está registrado.");
            }

            if (!ModelState.IsValid) return View(model);

            // Identity, la asignación de rol y el perfil comparten este DbContext.
            // Si falla cualquier paso, no queda una cuenta sin rol ni perfil.
            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var user = new IdentityUser { UserName = model.Email, Email = model.Email };
                var resultado = await _userManager.CreateAsync(user, model.Password);
                if (!resultado.Succeeded)
                {
                    AgregarErrores(resultado);
                    return View(model);
                }

                resultado = await _userManager.AddToRoleAsync(
                    user, model.EsAdministrador ? DbSeeder.RolAdministrador : DbSeeder.RolCliente);
                if (!resultado.Succeeded)
                {
                    AgregarErrores(resultado);
                    return View(model);
                }

                if (model.EsAdministrador)
                {
                    resultado = await _userManager.AddClaimsAsync(user, new[]
                    {
                        new Claim(ClaimTypes.GivenName, model.Nombre),
                        new Claim(ClaimTypes.Surname, model.Apellido)
                    });
                    if (!resultado.Succeeded)
                    {
                        AgregarErrores(resultado);
                        return View(model);
                    }
                }
                else
                {
                    _context.Clientes.Add(new Cliente
                    {
                        AspNetUserId = user.Id,
                        Nombre = model.Nombre,
                        Apellido = model.Apellido,
                        Dui = model.DUI,
                        Telefono = model.Telefono?.Trim()
                    });
                    await _context.SaveChangesAsync();
                }

                await transaction.CommitAsync();
                await _signInManager.SignInAsync(user, isPersistent: false);
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    return Redirect(returnUrl);
                return RedirectToAction("Index", "Home");
            }
            catch (DbUpdateException)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty,
                    "No se pudo completar el registro. Revisa si el correo o DUI ya están registrados.");
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (!ModelState.IsValid) return View(model);

            var correo = model.Email.Trim().ToLowerInvariant();
            var usuario = await _userManager.FindByEmailAsync(correo);
            if (usuario != null)
            {
                var estadoEmpleado = (await _userManager.GetClaimsAsync(usuario))
                    .FirstOrDefault(c => c.Type == "EstadoEmpleado")?.Value;
                if (string.Equals(estadoEmpleado, "Suspendido", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(estadoEmpleado, "Despedido", StringComparison.OrdinalIgnoreCase))
                {
                    ModelState.AddModelError(string.Empty, estadoEmpleado == "Despedido"
                        ? "Esta cuenta de empleado fue dada de baja."
                        : "Esta cuenta de empleado está suspendida.");
                    return View(model);
                }
            }

            var result = await _signInManager.PasswordSignInAsync(
                correo, model.Password, model.RememberMe, lockoutOnFailure: true);

            if (result.Succeeded)
            {
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    return Redirect(returnUrl);

                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError(string.Empty, result.IsLockedOut
                ? "Cuenta bloqueada temporalmente por varios intentos fallidos. Intenta de nuevo en 15 minutos."
                : "Usuario o contraseña incorrectos.");
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Perfil()
        {
            var usuario = await _userManager.GetUserAsync(User);
            if (usuario == null) return Challenge();

            return View(await ConstruirPerfilAsync(usuario));
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ActualizarCorreo(ActualizarCorreoViewModel model)
        {
            model.Email = model.Email?.Trim().ToLowerInvariant() ?? string.Empty;

            if (!ModelState.IsValid)
            {
                TempData["ErrorPerfil"] = PrimerErrorDelModelo();
                return RedirectToAction(nameof(Perfil));
            }

            var usuario = await _userManager.GetUserAsync(User);
            if (usuario == null) return Challenge();

            if (!await _userManager.CheckPasswordAsync(usuario, model.PasswordActual))
            {
                TempData["ErrorPerfil"] = "La contraseña actual no es correcta. El correo no fue modificado.";
                return RedirectToAction(nameof(Perfil));
            }

            var existente = await _userManager.FindByEmailAsync(model.Email);
            if (existente != null && existente.Id != usuario.Id)
            {
                TempData["ErrorPerfil"] = "Ese correo ya está asociado a otra cuenta.";
                return RedirectToAction(nameof(Perfil));
            }

            if (string.Equals(usuario.Email, model.Email, StringComparison.OrdinalIgnoreCase))
            {
                TempData["InfoPerfil"] = "El correo indicado ya es el correo actual de tu cuenta.";
                return RedirectToAction(nameof(Perfil));
            }

            usuario.Email = model.Email;
            usuario.UserName = model.Email;
            usuario.EmailConfirmed = true;

            var resultado = await _userManager.UpdateAsync(usuario);
            if (!resultado.Succeeded)
            {
                TempData["ErrorPerfil"] = string.Join(" ", resultado.Errors.Select(e => e.Description));
                return RedirectToAction(nameof(Perfil));
            }

            await _userManager.UpdateSecurityStampAsync(usuario);
            await _signInManager.RefreshSignInAsync(usuario);
            TempData["ExitoPerfil"] = "Correo actualizado correctamente.";
            return RedirectToAction(nameof(Perfil));
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CambiarPassword(CambiarPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                TempData["ErrorPerfil"] = PrimerErrorDelModelo();
                return RedirectToAction(nameof(Perfil));
            }

            var usuario = await _userManager.GetUserAsync(User);
            if (usuario == null) return Challenge();

            var resultado = await _userManager.ChangePasswordAsync(usuario, model.PasswordActual, model.NuevaPassword);
            if (!resultado.Succeeded)
            {
                TempData["ErrorPerfil"] = string.Join(" ", resultado.Errors.Select(e => e.Description));
                return RedirectToAction(nameof(Perfil));
            }

            await _signInManager.RefreshSignInAsync(usuario);
            TempData["ExitoPerfil"] = "Contraseña actualizada correctamente.";
            return RedirectToAction(nameof(Perfil));
        }

        [HttpGet]
        public IActionResult AccessDenied() => View();

        private async Task<PerfilUsuarioViewModel> ConstruirPerfilAsync(IdentityUser usuario)
        {
            var roles = await _userManager.GetRolesAsync(usuario);
            var perfil = new PerfilUsuarioViewModel
            {
                Email = usuario.Email ?? usuario.UserName ?? string.Empty,
                TipoCuenta = roles.Count > 0 ? string.Join(" / ", roles) : "Usuario"
            };

            var empleado = await _context.Empleados
                .Include(e => e.Cargo)
                .Include(e => e.Horario)
                .FirstOrDefaultAsync(e => e.AspNetUserId == usuario.Id);

            if (empleado != null)
            {
                perfil.Nombre = empleado.Nombre;
                perfil.Apellido = empleado.Apellido;
                perfil.Dui = empleado.Dui;
                perfil.FechaNacimiento = empleado.FechaNacimiento;
                perfil.Sexo = empleado.Sexo;
                perfil.Cargo = empleado.Cargo?.Nombre;
                perfil.Turno = empleado.Horario?.Turno;
                perfil.Estado = (await _userManager.GetClaimsAsync(usuario))
                    .FirstOrDefault(c => c.Type == "EstadoEmpleado")?.Value ?? "Activo";
                return perfil;
            }

            var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.AspNetUserId == usuario.Id);
            if (cliente != null)
            {
                perfil.Nombre = cliente.Nombre;
                perfil.Apellido = cliente.Apellido;
                perfil.Dui = cliente.Dui;
                perfil.Telefono = cliente.Telefono;
                return perfil;
            }

            var claims = await _userManager.GetClaimsAsync(usuario);
            perfil.Nombre = claims.FirstOrDefault(c => c.Type == ClaimTypes.GivenName)?.Value ?? string.Empty;
            perfil.Apellido = claims.FirstOrDefault(c => c.Type == ClaimTypes.Surname)?.Value ?? string.Empty;
            return perfil;
        }

        private string PrimerErrorDelModelo()
        {
            return ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Revisa los datos ingresados." : e.ErrorMessage)
                .FirstOrDefault() ?? "Revisa los datos ingresados.";
        }

        private bool ClaveAdministradorValida(string? recibida)
        {
            var configurada = _configuration["AdminRegistration:Secret"];
            if (string.IsNullOrEmpty(recibida) || string.IsNullOrEmpty(configurada)) return false;

            var hashConfigurada = SHA256.HashData(Encoding.UTF8.GetBytes(configurada));
            var hashRecibida = SHA256.HashData(Encoding.UTF8.GetBytes(recibida));
            return CryptographicOperations.FixedTimeEquals(hashConfigurada, hashRecibida);
        }

        private void AgregarErrores(IdentityResult resultado)
        {
            foreach (var error in resultado.Errors)
                ModelState.AddModelError(string.Empty, error.Description);
        }
    }
}
