using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GestionHotelera.Data;
using GestionHotelera.Models;
using GestionHotelera.Models.Enums;
using GestionHotelera.Models.Home;
using GestionHotelera.Services;

namespace GestionHotelera.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public HomeController(ApplicationDbContext context) => _context = context;

        // Página de inicio: catálogo de habitaciones con filtros.
        public async Task<IActionResult> Index(FiltroHabitacionesViewModel filtro)
        {
            var query = _context.Habitaciones.AsNoTracking();

            var buscaFechas = filtro.FechaEntrada.HasValue || filtro.FechaSalida.HasValue;
            var fechasValidas = filtro.FechaEntrada.HasValue && filtro.FechaSalida.HasValue
                && filtro.FechaEntrada.Value.Date >= HotelClock.Today
                && filtro.FechaSalida.Value.Date > filtro.FechaEntrada.Value.Date;
            if (buscaFechas && !fechasValidas)
                filtro.MensajeFechas = "Selecciona entrada y salida válidas; la salida debe ser posterior a la entrada.";
            if (fechasValidas)
            {
                var entrada = filtro.FechaEntrada!.Value.Date;
                var salida = filtro.FechaSalida!.Value.Date;
                query = query.Where(h => h.Estado == EstadoHabitacion.Disponible &&
                    !_context.Reservas.Any(r => r.HabitacionId == h.Id &&
                        r.EstadoReserva != EstadoReserva.Cancelada && r.EstadoReserva != EstadoReserva.Finalizada &&
                        r.FechaEntrada < salida && r.FechaSalida > entrada));
            }

            if (filtro.Piso.HasValue)
            {
                query = query.Where(h => h.Piso == filtro.Piso.Value);
            }

            if (filtro.CapacidadMinima.HasValue)
            {
                query = query.Where(h => h.Capacidad >= filtro.CapacidadMinima.Value);
            }

            if (filtro.CapacidadMaxima.HasValue)
            {
                query = query.Where(h => h.Capacidad <= filtro.CapacidadMaxima.Value);
            }

            if (filtro.Estado == "Disponible")
            {
                query = query.Where(h => h.Estado == EstadoHabitacion.Disponible);
            }
            else if (filtro.Estado == "Ocupada")
            {
                query = query.Where(h => h.Estado != EstadoHabitacion.Disponible);
            }

            var habitaciones = await query.ToListAsync();

            // Se consultan solo los conteos: no es necesario cargar todas las
            // reservas y habitaciones en memoria cada vez que se abre el catálogo.
            var conteos = await _context.Reservas.AsNoTracking()
                .Where(r => r.EstadoReserva != EstadoReserva.Cancelada)
                .GroupBy(r => r.HabitacionId)
                .Select(g => new { HabitacionId = g.Key, Total = g.Count() })
                .ToDictionaryAsync(g => g.HabitacionId, g => g.Total);

            var idsPopulares = conteos.OrderByDescending(x => x.Value)
                .Take(3)
                .Select(x => x.Key)
                .ToHashSet();

            IEnumerable<GestionHotelera.Models.Entidades.Habitacion> ordenadas = filtro.OrdenarPor switch
            {
                "Populares" => habitaciones.OrderByDescending(h => conteos.GetValueOrDefault(h.Id)),
                "PrecioAsc" => habitaciones.OrderBy(h => h.Precio),
                "PrecioDesc" => habitaciones.OrderByDescending(h => h.Precio),
                _ => habitaciones.OrderBy(h => h.Numero)
            };

            filtro.Habitaciones = ordenadas.Select(h => new HabitacionCardViewModel
            {
                Id = h.Id,
                Numero = h.Numero,
                Tipo = h.Tipo,
                Capacidad = h.Capacidad,
                NumeroCamas = h.NumeroCamas,
                Piso = h.Piso,
                Precio = h.Precio,
                Estado = h.Estado,
                ImagenUrl = h.ImagenUrl,
                EsPopular = idsPopulares.Contains(h.Id)
            }).ToList();

            var pisosDisponibles = await _context.Habitaciones
                .Select(h => h.Piso)
                .Distinct()
                .OrderBy(p => p)
                .ToListAsync();

            filtro.Pisos = pisosDisponibles
                .Select(p => new SelectListItem($"Piso {p}", p.ToString()))
                .ToList();

            return View(filtro);
        }

        public IActionResult ComoFunciona() => View();

        // Conserva enlaces previos sin duplicar información ni consultas.
        public IActionResult Privacy() => RedirectToAction(nameof(ComoFunciona));

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
