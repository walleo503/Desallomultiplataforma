using System.Security.Claims;
using GestionHotelera.Data;
using GestionHotelera.Models.Authorization;
using GestionHotelera.Models.Empleados;
using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;
using GestionHotelera.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GestionHotelera.Controllers
{
    [Authorize]
    public class EmpleadosController : Controller
    {
        private const string EstadoClaim = "EstadoEmpleado";
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ApplicationDbContext _context;

        public EmpleadosController(UserManager<IdentityUser> userManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        [Authorize(Policy = Permisos.EmpleadosVer)]
        public async Task<IActionResult> Index()
        {
            var empleados = await _context.Empleados
                .Include(e => e.Cargo)
                .Include(e => e.Horario)
                .OrderBy(e => e.Apellido)
                .ThenBy(e => e.Nombre)
                .ToListAsync();

            foreach (var empleado in empleados)
            {
                var usuario = await _userManager.FindByIdAsync(empleado.AspNetUserId);
                empleado.Estado = usuario == null ? EstadoEmpleado.Despedido : await ObtenerEstadoAsync(usuario);
            }

            return View(empleados);
        }

        [HttpGet]
        [Authorize(Policy = Permisos.EmpleadosCrear)]
        public async Task<IActionResult> Create()
        {
            var model = new CrearEmpleadoViewModel();
            await CargarOpcionesAsync(model);
            return View(model);
        }

        [HttpPost]
        [Authorize(Policy = Permisos.EmpleadosCrear)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CrearEmpleadoViewModel model)
        {
            model.Email = model.Email?.Trim().ToLowerInvariant() ?? string.Empty;
            model.Dui = model.Dui?.Trim() ?? string.Empty;
            model.Nombre = model.Nombre?.Trim() ?? string.Empty;
            model.Apellido = model.Apellido?.Trim() ?? string.Empty;

            var cargo = await _context.Cargos.FindAsync(model.CargoId);
            var rolInterno = ObtenerRolDesdeCargo(cargo?.Nombre);
            if (cargo == null || rolInterno == null)
                ModelState.AddModelError(nameof(model.CargoId), "Selecciona un cargo válido: Administrador o Secretario.");

            if (!model.FechaNacimiento.HasValue || model.FechaNacimiento.Value.Date < new DateTime(1900, 1, 1) ||
                model.FechaNacimiento.Value.Date > HotelClock.Today)
                ModelState.AddModelError(nameof(model.FechaNacimiento), "Indica una fecha de nacimiento válida entre 1900 y hoy.");

            if (!await _context.Horarios.AnyAsync(h => h.Id == model.HorarioId))
                ModelState.AddModelError(nameof(model.HorarioId), "Selecciona un turno válido.");

            if (!string.IsNullOrWhiteSpace(model.Dui) && await _context.Empleados.AnyAsync(e => e.Dui == model.Dui))
                ModelState.AddModelError(nameof(model.Dui), "Ya existe un empleado con ese DUI.");

            if (await _userManager.FindByEmailAsync(model.Email) != null)
                ModelState.AddModelError(nameof(model.Email), "Ya existe una cuenta con ese correo.");

            if (!ModelState.IsValid)
            {
                await CargarOpcionesAsync(model);
                return View(model);
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var user = new IdentityUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    EmailConfirmed = true,
                    LockoutEnabled = true
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    AgregarErrores(result);
                    await CargarOpcionesAsync(model);
                    return View(model);
                }

                result = await _userManager.AddToRoleAsync(user, rolInterno!);
                if (!result.Succeeded)
                {
                    AgregarErrores(result);
                    await CargarOpcionesAsync(model);
                    return View(model);
                }

                await _userManager.AddClaimAsync(user, new Claim(EstadoClaim, EstadoEmpleado.Activo.ToString()));

                _context.Empleados.Add(new Empleado
                {
                    AspNetUserId = user.Id,
                    Nombre = model.Nombre,
                    Apellido = model.Apellido,
                    FechaNacimiento = model.FechaNacimiento!.Value.Date,
                    Sexo = model.Sexo?.Trim(),
                    Dui = model.Dui,
                    CargoId = model.CargoId,
                    HorarioId = model.HorarioId
                });

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                TempData["Exito"] = $"Empleado {model.Nombre} {model.Apellido} creado como {cargo!.Nombre}.";
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateException)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty, "No se pudo crear el empleado. Revisa el correo y el DUI.");
                await CargarOpcionesAsync(model);
                return View(model);
            }
        }

        [HttpGet]
        [Authorize(Policy = Permisos.EmpleadosEditar)]
        public async Task<IActionResult> Edit(int id)
        {
            var empleado = await _context.Empleados.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
            if (empleado == null) return NotFound();
            var usuario = await _userManager.FindByIdAsync(empleado.AspNetUserId);
            if (usuario == null) return NotFound();

            var model = new EditarEmpleadoViewModel
            {
                Id = empleado.Id,
                Nombre = empleado.Nombre,
                Apellido = empleado.Apellido,
                Dui = empleado.Dui,
                FechaNacimiento = empleado.FechaNacimiento,
                Sexo = empleado.Sexo,
                Email = usuario.Email ?? usuario.UserName ?? string.Empty,
                CargoId = empleado.CargoId,
                HorarioId = empleado.HorarioId,
                Estado = await ObtenerEstadoAsync(usuario)
            };
            await CargarOpcionesEdicionAsync(model);
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.EmpleadosEditar)]
        public async Task<IActionResult> Edit(int id, EditarEmpleadoViewModel model)
        {
            if (id != model.Id) return BadRequest();

            model.Nombre = model.Nombre?.Trim() ?? string.Empty;
            model.Apellido = model.Apellido?.Trim() ?? string.Empty;
            model.Dui = model.Dui?.Trim() ?? string.Empty;
            model.Email = model.Email?.Trim().ToLowerInvariant() ?? string.Empty;

            var empleado = await _context.Empleados.FindAsync(id);
            if (empleado == null) return NotFound();
            var usuario = await _userManager.FindByIdAsync(empleado.AspNetUserId);
            if (usuario == null) return NotFound();

            var cargo = await _context.Cargos.FindAsync(model.CargoId);
            var rolNuevo = ObtenerRolDesdeCargo(cargo?.Nombre);
            if (cargo == null || rolNuevo == null)
                ModelState.AddModelError(nameof(model.CargoId), "Selecciona Administrador o Secretario.");

            if (model.FechaNacimiento == default || model.FechaNacimiento.Date < new DateTime(1900, 1, 1) ||
                model.FechaNacimiento.Date > HotelClock.Today)
                ModelState.AddModelError(nameof(model.FechaNacimiento), "Indica una fecha de nacimiento válida entre 1900 y hoy.");

            if (!await _context.Horarios.AnyAsync(h => h.Id == model.HorarioId))
                ModelState.AddModelError(nameof(model.HorarioId), "Selecciona un turno válido.");

            if (await _context.Empleados.AnyAsync(e => e.Dui == model.Dui && e.Id != id))
                ModelState.AddModelError(nameof(model.Dui), "Ese DUI pertenece a otro empleado.");

            var otroUsuario = await _userManager.FindByEmailAsync(model.Email);
            if (otroUsuario != null && otroUsuario.Id != usuario.Id)
                ModelState.AddModelError(nameof(model.Email), "Ese correo pertenece a otra cuenta.");

            var rolesActuales = await _userManager.GetRolesAsync(usuario);
            var esAdminActual = rolesActuales.Contains(DbSeeder.RolAdministrador);
            if (esAdminActual && (rolNuevo != DbSeeder.RolAdministrador || model.Estado != EstadoEmpleado.Activo))
            {
                var administradores = await _userManager.GetUsersInRoleAsync(DbSeeder.RolAdministrador);
                if (administradores.Count <= 1)
                    ModelState.AddModelError(nameof(model.Estado), "No puedes desactivar ni cambiar el cargo del único Administrador.");
            }

            if (!ModelState.IsValid)
            {
                await CargarOpcionesEdicionAsync(model);
                return View(model);
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                empleado.Nombre = model.Nombre;
                empleado.Apellido = model.Apellido;
                empleado.Dui = model.Dui;
                empleado.Sexo = model.Sexo?.Trim();
                empleado.FechaNacimiento = model.FechaNacimiento.Date;
                empleado.CargoId = model.CargoId;
                empleado.HorarioId = model.HorarioId;

                if (!string.Equals(usuario.Email, model.Email, StringComparison.OrdinalIgnoreCase))
                {
                    var emailResult = await _userManager.SetEmailAsync(usuario, model.Email);
                    if (!emailResult.Succeeded) { AgregarErrores(emailResult); throw new InvalidOperationException("email"); }
                    var userNameResult = await _userManager.SetUserNameAsync(usuario, model.Email);
                    if (!userNameResult.Succeeded) { AgregarErrores(userNameResult); throw new InvalidOperationException("username"); }
                    usuario.EmailConfirmed = true;
                    await _userManager.UpdateAsync(usuario);
                }

                if (!rolesActuales.Contains(rolNuevo!))
                {
                    if (rolesActuales.Count > 0)
                        await _userManager.RemoveFromRolesAsync(usuario, rolesActuales.Where(r => r == DbSeeder.RolAdministrador || r == DbSeeder.RolSecretario));
                    var roleResult = await _userManager.AddToRoleAsync(usuario, rolNuevo!);
                    if (!roleResult.Succeeded) { AgregarErrores(roleResult); throw new InvalidOperationException("role"); }
                }

                await EstablecerEstadoAsync(usuario, model.Estado);
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
                TempData["Exito"] = "Datos y estado del empleado actualizados.";
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                await transaction.RollbackAsync();
                if (ModelState.IsValid)
                    ModelState.AddModelError(string.Empty, "No se pudieron guardar los cambios del empleado.");
                await CargarOpcionesEdicionAsync(model);
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.EmpleadosEditar)]
        public async Task<IActionResult> CambiarEstado(int id, EstadoEmpleado estado)
        {
            if (!Enum.IsDefined(estado)) return BadRequest();
            var empleado = await _context.Empleados.FindAsync(id);
            if (empleado == null) return NotFound();
            var usuario = await _userManager.FindByIdAsync(empleado.AspNetUserId);
            if (usuario == null) return NotFound();

            var usuarioActual = await _userManager.GetUserAsync(User);
            if (usuarioActual?.Id == usuario.Id && estado != EstadoEmpleado.Activo)
            {
                TempData["Error"] = "No puedes suspender o despedir tu propia cuenta mientras la estás usando.";
                return RedirectToAction(nameof(Index));
            }

            if (await _userManager.IsInRoleAsync(usuario, DbSeeder.RolAdministrador) && estado != EstadoEmpleado.Activo)
            {
                var administradores = await _userManager.GetUsersInRoleAsync(DbSeeder.RolAdministrador);
                if (administradores.Count <= 1)
                {
                    TempData["Error"] = "No puedes desactivar el único Administrador del sistema.";
                    return RedirectToAction(nameof(Index));
                }
            }

            await EstablecerEstadoAsync(usuario, estado);
            TempData["Exito"] = $"{empleado.Nombre} {empleado.Apellido} ahora está {estado}.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = Permisos.EmpleadosEliminar)]
        public async Task<IActionResult> Delete(int id)
        {
            var empleado = await _context.Empleados.FindAsync(id);
            if (empleado == null) return NotFound();
            var usuario = await _userManager.FindByIdAsync(empleado.AspNetUserId);
            if (usuario == null) return NotFound();

            var usuarioActual = await _userManager.GetUserAsync(User);
            if (usuarioActual?.Id == usuario.Id)
            {
                TempData["Error"] = "No puedes eliminar tu propia cuenta mientras la estás usando.";
                return RedirectToAction(nameof(Index));
            }

            if (await _userManager.IsInRoleAsync(usuario, DbSeeder.RolAdministrador))
            {
                var administradores = await _userManager.GetUsersInRoleAsync(DbSeeder.RolAdministrador);
                if (administradores.Count <= 1)
                {
                    TempData["Error"] = "No puedes eliminar el único Administrador del sistema.";
                    return RedirectToAction(nameof(Index));
                }
            }

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                _context.Empleados.Remove(empleado);
                await _context.SaveChangesAsync();
                var result = await _userManager.DeleteAsync(usuario);
                if (!result.Succeeded) throw new InvalidOperationException(string.Join("; ", result.Errors.Select(e => e.Description)));
                await transaction.CommitAsync();
                TempData["Exito"] = "Empleado eliminado correctamente.";
            }
            catch
            {
                await transaction.RollbackAsync();
                TempData["Error"] = "No se pudo eliminar el empleado porque existen datos relacionados o la cuenta no pudo borrarse.";
            }
            return RedirectToAction(nameof(Index));
        }

        private async Task CargarOpcionesEdicionAsync(EditarEmpleadoViewModel model)
        {
            model.Cargos = await ObtenerCargosAsync();
            model.Horarios = await ObtenerHorariosAsync();
        }

        private async Task CargarOpcionesAsync(CrearEmpleadoViewModel model)
        {
            model.Cargos = await ObtenerCargosAsync();
            model.Horarios = await ObtenerHorariosAsync();
        }

        private async Task<List<SelectListItem>> ObtenerCargosAsync() => await _context.Cargos
            .Where(c => c.Nombre == "Administrador" || c.Nombre == "Secretario")
            .OrderBy(c => c.Nombre)
            .Select(c => new SelectListItem(c.Nombre, c.Id.ToString()))
            .ToListAsync();

        private async Task<List<SelectListItem>> ObtenerHorariosAsync()
        {
            var horarios = await _context.Horarios
                .Where(h => h.Turno == "Mañana" || h.Turno == "Tarde" || h.Turno == "Noche")
                .OrderBy(h => h.Turno == "Mañana" ? 1 : h.Turno == "Tarde" ? 2 : 3)
                .ToListAsync();
            return horarios.Select(h => new SelectListItem(
                h.Turno + (string.IsNullOrWhiteSpace(h.Descripcion) ? "" : $" ({h.Descripcion})"), h.Id.ToString())).ToList();
        }

        private static string? ObtenerRolDesdeCargo(string? cargo) => cargo switch
        {
            "Administrador" => DbSeeder.RolAdministrador,
            "Secretario" => DbSeeder.RolSecretario,
            _ => null
        };

        private async Task<EstadoEmpleado> ObtenerEstadoAsync(IdentityUser usuario)
        {
            var valor = (await _userManager.GetClaimsAsync(usuario)).FirstOrDefault(c => c.Type == EstadoClaim)?.Value;
            return Enum.TryParse<EstadoEmpleado>(valor, true, out var estado) ? estado : EstadoEmpleado.Activo;
        }

        private async Task EstablecerEstadoAsync(IdentityUser usuario, EstadoEmpleado estado)
        {
            var claims = await _userManager.GetClaimsAsync(usuario);
            foreach (var claim in claims.Where(c => c.Type == EstadoClaim))
                await _userManager.RemoveClaimAsync(usuario, claim);
            await _userManager.AddClaimAsync(usuario, new Claim(EstadoClaim, estado.ToString()));

            if (estado == EstadoEmpleado.Activo)
            {
                await _userManager.SetLockoutEndDateAsync(usuario, null);
                await _userManager.ResetAccessFailedCountAsync(usuario);
            }
            else
            {
                await _userManager.SetLockoutEndDateAsync(usuario, DateTimeOffset.MaxValue);
                await _userManager.UpdateSecurityStampAsync(usuario);
            }
        }

        private void AgregarErrores(IdentityResult result)
        {
            foreach (var error in result.Errors)
                ModelState.AddModelError(string.Empty, error.Description);
        }
    }
}
