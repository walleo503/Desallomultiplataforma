using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionHotelera.Data;
using GestionHotelera.Models.Authorization;
using GestionHotelera.Models.Entidades;
using GestionHotelera.Models.Enums;
using GestionHotelera.Models.Habitaciones;
using GestionHotelera.Services;

namespace GestionHotelera.Controllers
{
    // El listado público (catálogo) vive en HomeController.
    // Este controlador maneja el DETALLE público (con reserva) y toda la
    // ADMINISTRACIÓN de habitaciones (crear/editar/eliminar/cambiar estado),
    // cada acción protegida con su propio permiso.
    public class HabitacionesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IWebHostEnvironment _environment;
        private static readonly string[] ExtensionesImagenPermitidas = { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
        private const long TamanoMaximoImagen = 5 * 1024 * 1024;

        public HabitacionesController(ApplicationDbContext context, UserManager<IdentityUser> userManager, IWebHostEnvironment environment)
        {
            _context = context;
            _userManager = userManager;
            _environment = environment;
        }

        // ---------- Detalle público (con formulario de reserva) ----------

        public async Task<IActionResult> Detalle(int id, DateTime? fechaEntrada, DateTime? fechaSalida, int? cantidadHuespedes)
        {
            var habitacion = await _context.Habitaciones.FirstOrDefaultAsync(h => h.Id == id);
            if (habitacion == null)
            {
                return NotFound();
            }

            var vm = new DetalleHabitacionViewModel
            {
                Id = habitacion.Id,
                Numero = habitacion.Numero,
                Tipo = habitacion.Tipo,
                Capacidad = habitacion.Capacidad,
                NumeroCamas = habitacion.NumeroCamas,
                Piso = habitacion.Piso,
                Precio = habitacion.Precio,
                Descripcion = habitacion.Descripcion,
                ImagenUrl = habitacion.ImagenUrl,
                Estado = habitacion.Estado,
                CantidadHuespedes = Math.Clamp(cantidadHuespedes ?? 1, 1, habitacion.Capacidad),
                FechaEntrada = fechaEntrada?.Date,
                FechaSalida = fechaSalida?.Date
            };

            if (fechaEntrada.HasValue && fechaSalida.HasValue &&
                fechaEntrada.Value.Date >= HotelClock.Today && fechaSalida.Value.Date > fechaEntrada.Value.Date)
            {
                vm.DisponibleFechas = !await _context.Reservas.AnyAsync(r =>
                    r.HabitacionId == id && r.EstadoReserva != EstadoReserva.Cancelada &&
                    r.EstadoReserva != EstadoReserva.Finalizada &&
                    r.FechaEntrada < fechaSalida.Value.Date && r.FechaSalida > fechaEntrada.Value.Date);
            }

            if (User.Identity == null || !User.Identity.IsAuthenticated)
            {
                vm.UsuarioNoAutenticado = true;
            }
            else
            {
                var usuario = await _userManager.GetUserAsync(User);
                var tieneCliente = usuario != null &&
                    await _context.Clientes.AnyAsync(c => c.AspNetUserId == usuario.Id);

                vm.UsuarioSinPerfilCliente = !tieneCliente;
                vm.PuedeGestionarReservas = !tieneCliente &&
                    User.HasClaim("Permission", Permisos.ReservasCrear) &&
                    User.HasClaim("Permission", Permisos.ReservasVerTodas);
                if (vm.PuedeGestionarReservas)
                {
                    vm.HistorialReservas = await _context.Reservas.AsNoTracking()
                        .Where(r => r.HabitacionId == id)
                        .Include(r => r.Cliente)
                        .Include(r => r.Empleado).ThenInclude(e => e!.Cargo)
                        .OrderByDescending(r => r.FechaReserva)
                        .Take(20)
                        .ToListAsync();
                }
            }

            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> Disponibilidad(int id, DateTime entrada, DateTime salida)
        {
            if (entrada.Date < HotelClock.Today || salida.Date <= entrada.Date ||
                salida.Date > HotelClock.Today.AddYears(2))
                return BadRequest(new { mensaje = "Selecciona fechas válidas dentro de los próximos dos años." });

            var habitacion = await _context.Habitaciones.AsNoTracking()
                .Where(h => h.Id == id)
                .Select(h => new { h.Estado }).FirstOrDefaultAsync();
            if (habitacion == null) return NotFound();

            var reservada = await _context.Reservas.AsNoTracking().AnyAsync(r =>
                r.HabitacionId == id && r.EstadoReserva != EstadoReserva.Cancelada &&
                r.EstadoReserva != EstadoReserva.Finalizada &&
                r.FechaEntrada < salida.Date && r.FechaSalida > entrada.Date);
            return Json(new { disponible = habitacion.Estado == EstadoHabitacion.Disponible && !reservada });
        }

        // ---------- Administración (Administrador / Secretario, según permiso) ----------

        [Authorize(Roles = "Administrador,Secretario", Policy = Permisos.HabitacionesVer)]
        public async Task<IActionResult> Administrar()
        {
            var habitaciones = await _context.Habitaciones
                .OrderBy(h => h.Piso)
                .ThenBy(h => h.Numero)
                .ToListAsync();
            return View(habitaciones);
        }

        [HttpGet]
        [Authorize(Policy = Permisos.HabitacionesCrear)]
        public IActionResult Crear()
        {
            return View(new HabitacionFormViewModel());
        }

        [HttpPost]
        [Authorize(Policy = Permisos.HabitacionesCrear)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear(HabitacionFormViewModel model)
        {
            model.Numero = model.Numero?.Trim() ?? string.Empty;
            ValidarImagen(model);
            if (!Enum.IsDefined(model.Estado))
                ModelState.AddModelError(nameof(model.Estado), "Selecciona un estado válido.");
            if (await _context.Habitaciones.AnyAsync(h => h.Numero == model.Numero))
            {
                ModelState.AddModelError(nameof(model.Numero), "Ya existe una habitación con ese número.");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var imagenGuardada = await GuardarImagenAsync(model.ImagenArchivo);
            _context.Habitaciones.Add(new Habitacion
            {
                Numero = model.Numero,
                Tipo = model.Tipo,
                Capacidad = model.Capacidad,
                NumeroCamas = model.NumeroCamas,
                Piso = model.Piso,
                Precio = model.Precio,
                Descripcion = model.Descripcion,
                ImagenUrl = imagenGuardada ?? NormalizarUrl(model.ImagenUrl),
                Estado = model.Estado
            });
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError(nameof(model.Numero), "No se pudo guardar: verifica que el número no esté registrado.");
                return View(model);
            }

            TempData["Exito"] = $"Habitación {model.Numero} creada correctamente.";
            return RedirectToAction(nameof(Administrar));
        }

        [HttpGet]
        [Authorize(Policy = Permisos.HabitacionesEditar)]
        public async Task<IActionResult> Editar(int id)
        {
            var habitacion = await _context.Habitaciones.FindAsync(id);
            if (habitacion == null)
            {
                return NotFound();
            }

            var model = new HabitacionFormViewModel
            {
                Id = habitacion.Id,
                Numero = habitacion.Numero,
                Tipo = habitacion.Tipo,
                Capacidad = habitacion.Capacidad,
                NumeroCamas = habitacion.NumeroCamas,
                Piso = habitacion.Piso,
                Precio = habitacion.Precio,
                Descripcion = habitacion.Descripcion,
                ImagenUrl = habitacion.ImagenUrl,
                Estado = habitacion.Estado
            };

            return View(model);
        }

        [HttpPost]
        [Authorize(Policy = Permisos.HabitacionesEditar)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, HabitacionFormViewModel model)
        {
            model.Numero = model.Numero?.Trim() ?? string.Empty;
            if (!Enum.IsDefined(model.Estado))
                ModelState.AddModelError(nameof(model.Estado), "Selecciona un estado válido.");
            if (id != model.Id)
            {
                return BadRequest();
            }

            var habitacion = await _context.Habitaciones.FindAsync(id);
            if (habitacion == null)
            {
                return NotFound();
            }

            ValidarImagen(model);
            bool numeroDuplicado = await _context.Habitaciones
                .AnyAsync(h => h.Numero == model.Numero && h.Id != id);
            if (numeroDuplicado)
            {
                ModelState.AddModelError(nameof(model.Numero), "Ya existe otra habitación con ese número.");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            habitacion.Numero = model.Numero;
            habitacion.Tipo = model.Tipo;
            habitacion.Capacidad = model.Capacidad;
            habitacion.NumeroCamas = model.NumeroCamas;
            habitacion.Piso = model.Piso;
            habitacion.Precio = model.Precio;
            habitacion.Descripcion = model.Descripcion;
            if (model.ImagenArchivo != null)
            {
                var nuevaImagen = await GuardarImagenAsync(model.ImagenArchivo);
                if (nuevaImagen != null)
                {
                    EliminarImagenLocal(habitacion.ImagenUrl);
                    habitacion.ImagenUrl = nuevaImagen;
                }
            }
            else
            {
                var urlNueva = NormalizarUrl(model.ImagenUrl);
                if (!string.Equals(habitacion.ImagenUrl, urlNueva, StringComparison.OrdinalIgnoreCase))
                    EliminarImagenLocal(habitacion.ImagenUrl);
                habitacion.ImagenUrl = urlNueva;
            }
            habitacion.Estado = model.Estado;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError(nameof(model.Numero), "No se pudo guardar: verifica que el número no esté registrado.");
                return View(model);
            }

            TempData["Exito"] = $"Habitación {habitacion.Numero} actualizada correctamente.";
            return RedirectToAction(nameof(Administrar));
        }

        [HttpPost]
        [Authorize(Policy = Permisos.HabitacionesEliminar)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Eliminar(int id)
        {
            var habitacion = await _context.Habitaciones.FindAsync(id);
            if (habitacion == null)
            {
                return NotFound();
            }

            bool tieneReservas = await _context.Reservas.AnyAsync(r => r.HabitacionId == id);
            if (tieneReservas)
            {
                TempData["Error"] = $"No se puede eliminar la habitación {habitacion.Numero}: tiene reservas registradas. " +
                                     "Márcala como \"Mantenimiento\" en vez de eliminarla.";
                return RedirectToAction(nameof(Administrar));
            }

            EliminarImagenLocal(habitacion.ImagenUrl);
            _context.Habitaciones.Remove(habitacion);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                TempData["Error"] = "No se puede eliminar esta habitación porque ya tiene registros relacionados.";
                return RedirectToAction(nameof(Administrar));
            }

            TempData["Exito"] = $"Habitación {habitacion.Numero} eliminada.";
            return RedirectToAction(nameof(Administrar));
        }

        // Cambiar solo el estado (Disponible / Ocupada / Limpieza / Mantenimiento).
        // Lo puede hacer también el Secretario (p. ej. limpieza -> disponible),
        // sin necesidad del permiso completo de "editar" toda la habitación.
        [HttpPost]
        [Authorize(Policy = Permisos.HabitacionesCambiarEstado)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CambiarEstado(int id, EstadoHabitacion nuevoEstado)
        {
            if (!Enum.IsDefined(nuevoEstado)) return BadRequest();
            var habitacion = await _context.Habitaciones.FindAsync(id);
            if (habitacion == null)
            {
                return NotFound();
            }

            habitacion.Estado = nuevoEstado;
            await _context.SaveChangesAsync();

            TempData["Exito"] = $"Habitación {habitacion.Numero} ahora está: {nuevoEstado}.";
            return RedirectToAction(nameof(Administrar));
        }

        private void ValidarImagen(HabitacionFormViewModel model)
        {
            if (model.ImagenArchivo == null) return;
            var extension = Path.GetExtension(model.ImagenArchivo.FileName).ToLowerInvariant();
            if (!ExtensionesImagenPermitidas.Contains(extension))
                ModelState.AddModelError(nameof(model.ImagenArchivo), "Formato no permitido. Usa JPG, JPEG, PNG, WEBP o GIF.");
            if (model.ImagenArchivo.Length > TamanoMaximoImagen)
                ModelState.AddModelError(nameof(model.ImagenArchivo), "La imagen no puede superar 5 MB.");
        }

        private async Task<string?> GuardarImagenAsync(IFormFile? archivo)
        {
            if (archivo == null || archivo.Length == 0) return null;
            var extension = Path.GetExtension(archivo.FileName).ToLowerInvariant();
            var nombreArchivo = $"{Guid.NewGuid():N}{extension}";
            var carpeta = Path.Combine(_environment.WebRootPath, "uploads", "habitaciones");
            Directory.CreateDirectory(carpeta);
            var rutaFisica = Path.Combine(carpeta, nombreArchivo);
            await using var stream = new FileStream(rutaFisica, FileMode.Create);
            await archivo.CopyToAsync(stream);
            return $"/uploads/habitaciones/{nombreArchivo}";
        }

        private void EliminarImagenLocal(string? imagenUrl)
        {
            const string prefijo = "/uploads/habitaciones/";
            if (string.IsNullOrWhiteSpace(imagenUrl) || !imagenUrl.StartsWith(prefijo, StringComparison.OrdinalIgnoreCase)) return;
            var nombre = Path.GetFileName(imagenUrl);
            var ruta = Path.Combine(_environment.WebRootPath, "uploads", "habitaciones", nombre);
            if (System.IO.File.Exists(ruta)) System.IO.File.Delete(ruta);
        }

        private static string? NormalizarUrl(string? url) => string.IsNullOrWhiteSpace(url) ? null : url.Trim();
    }
}
