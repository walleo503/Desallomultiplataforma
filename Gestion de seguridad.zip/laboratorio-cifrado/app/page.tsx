import { CryptoLab } from "./crypto-lab";

export default function Home() {
  return <CryptoLab />;
}
