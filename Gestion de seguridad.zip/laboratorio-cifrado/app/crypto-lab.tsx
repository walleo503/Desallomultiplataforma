"use client";

import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowRight, BadgeCheck, Binary, Check, CheckCircle2, CircleAlert,
  Copy, FileKey2, Fingerprint, FlaskConical, KeyRound, LockKeyhole, RefreshCw,
  RotateCcw, ScanSearch, ShieldCheck, Sparkles, UnlockKeyhole,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

type Step = { title: string; detail: string; value?: string };
type HashAlgorithm = "SHA-256" | "SHA-512" | "MD5";
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}
function base64ToBytes(value: string) {
  return Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
}
function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function compact(value: string, size = 44) {
  if (value.length <= size) return value;
  const edge = Math.floor((size - 3) / 2);
  return `${value.slice(0, edge)}...${value.slice(-edge)}`;
}
async function publicKeyFingerprint(key: CryptoKey) {
  const exported = await crypto.subtle.exportKey("spki", key);
  const digest = await crypto.subtle.digest("SHA-256", exported);
  return bytesToHex(new Uint8Array(digest)).match(/.{1,4}/g)?.slice(0, 6).join(" ") ?? "";
}
async function calculateHash(algorithm: HashAlgorithm, text: string) {
  if (algorithm === "MD5") return md5(text);
  const digest = await crypto.subtle.digest(algorithm, encoder.encode(text));
  return bytesToHex(new Uint8Array(digest));
}

function md5(text: string) {
  const input = encoder.encode(text);
  const bitLength = input.length * 8;
  const paddedLength = Math.ceil((input.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(input);
  bytes[input.length] = 0x80;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 8, bitLength >>> 0, true);
  view.setUint32(paddedLength - 4, Math.floor(bitLength / 2 ** 32), true);
  const shifts = [
    7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
    5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
    4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
    6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21,
  ];
  const constants = Array.from({ length: 64 }, (_, i) =>
    Math.floor(Math.abs(Math.sin(i + 1)) * 2 ** 32) >>> 0
  );
  const rotateLeft = (value: number, amount: number) =>
    ((value << amount) | (value >>> (32 - amount))) >>> 0;
  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  for (let offset = 0; offset < paddedLength; offset += 64) {
    const words = Array.from({ length: 16 }, (_, i) => view.getUint32(offset + i * 4, true));
    let a = a0, b = b0, c = c0, d = d0;
    for (let i = 0; i < 64; i += 1) {
      let f: number, g: number;
      if (i < 16) { f = (b & c) | (~b & d); g = i; }
      else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
      else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
      else { f = c ^ (b | ~d); g = (7 * i) % 16; }
      const next = d;
      d = c;
      c = b;
      b = (b + rotateLeft((a + f + constants[i] + words[g]) >>> 0, shifts[i])) >>> 0;
      a = next;
    }
    a0 = (a0 + a) >>> 0; b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0; d0 = (d0 + d) >>> 0;
  }
  return [a0,b0,c0,d0]
    .map((word) => [0,8,16,24].map((s) => ((word >>> s) & 0xff).toString(16).padStart(2, "0")).join(""))
    .join("");
}

function FieldLabel({ children, hint }: { children: React.ReactNode; hint?: string }) {
  return <div className="field-label"><label>{children}</label>{hint ? <span>{hint}</span> : null}</div>;
}

function StatusMessage({ error, success }: { error?: string; success?: string }) {
  if (!error && !success) return null;
  return (
    <div className={`status ${error ? "status--error" : "status--success"}`} role="status">
      {error ? <CircleAlert /> : <CheckCircle2 />}
      <span>{error ?? success}</span>
    </div>
  );
}

function ResultBox({ title, value, plain = false }: { title: string; value: string; plain?: boolean }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    try { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1300); }
    catch { setCopied(false); }
  }
  return (
    <section className={`result ${plain ? "result--plain" : ""}`}>
      <div className="result__head">
        <span>{title}</span>
        <Button type="button" onClick={copy} className="copy-button" size="xs" variant="ghost">
          {copied ? <Check /> : <Copy />}{copied ? "Copiado" : "Copiar"}
        </Button>
      </div>
      <div className="result__body"><code>{value}</code></div>
    </section>
  );
}

function ProcessPanel({ title, operation, steps }: { title: string; operation: string; steps: Step[] }) {
  return (
    <aside className="process-panel">
      <div className="process-head">
        <div><p>Explicación para exponer</p><h3>{title}</h3></div>
        <span className="operation-tag">{operation}</span>
      </div>
      <div>
        {steps.map((step, index) => (
          <article className="step" key={`${step.title}-${index}`}>
            <div className="step__number">{String(index + 1).padStart(2, "0")}</div>
            <div className="step__content">
              <h4>{step.title}</h4>
              <p>{step.detail}</p>
              {step.value ? <code>{step.value}</code> : <span className="step__waiting">Se completa al ejecutar</span>}
            </div>
          </article>
        ))}
      </div>
    </aside>
  );
}

function ModuleHeader({ number, category, title, description }: { number: string; category: string; title: string; description: string }) {
  return (
    <header className="module-heading">
      <div><span className="eyebrow">{number} / {category}</span><h2>{title}</h2></div>
      <p>{description}</p>
    </header>
  );
}

function Facts({ sentence, protects, doesNot, useCase }: { sentence: string; protects: string; doesNot: string; useCase: string }) {
  return (
    <section className="facts">
      <div className="fact"><span className="fact__label">En una frase</span><p>{sentence}</p></div>
      <div className="fact"><span className="fact__label">Qué protege</span><p>{protects}</p></div>
      <div className="fact"><span className="fact__label">Qué no hace</span><p>{doesNot}</p></div>
      <div className="fact"><span className="fact__label">Uso real</span><p>{useCase}</p></div>
    </section>
  );
}

const aesInitial: Step[] = [
  { title: "Convertir el texto en bytes", detail: "El navegador representa el mensaje con codificación UTF-8." },
  { title: "Crear la clave de 256 bits", detail: "PBKDF2 mezcla contraseña y salt durante 100,000 iteraciones." },
  { title: "Generar un IV irrepetible", detail: "El IV hace que el mismo mensaje produzca resultados distintos." },
  { title: "Cifrar y autenticar", detail: "AES-GCM transforma los bytes y añade control de integridad." },
];

function AesLab() {
  const [message, setMessage] = useState("La información es poder.");
  const [password, setPassword] = useState("ClaveSegura2026!");
  const [cipherPackage, setCipherPackage] = useState("");
  const [decrypted, setDecrypted] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [operation, setOperation] = useState("Cifrado");
  const [steps, setSteps] = useState<Step[]>(aesInitial);

  async function deriveKey(passwordValue: string, salt: Uint8Array) {
    const material = await crypto.subtle.importKey("raw", encoder.encode(passwordValue), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", hash: "SHA-256", salt, iterations: 100_000 },
      material, 256,
    );
    const raw = new Uint8Array(bits);
    const key = await crypto.subtle.importKey("raw", raw, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
    return { key, raw };
  }

  async function encryptMessage() {
    if (!message.trim() || !password) { setError("Escribe un mensaje y una contraseña."); return; }
    setBusy(true); setError(""); setDecrypted(""); setOperation("Cifrado");
    try {
      const plain = encoder.encode(message);
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const { key, raw } = await deriveKey(password, salt);
      const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plain);
      const data = bytesToBase64(new Uint8Array(encrypted));
      setCipherPackage(JSON.stringify({
        v: 1, alg: "AES-256-GCM",
        salt: bytesToBase64(salt), iv: bytesToBase64(iv), data,
      }));
      setSteps([
        { title: "Convertir el texto en bytes", detail: "El navegador representa el mensaje con codificación UTF-8.", value: `${plain.length} bytes · ${compact(bytesToHex(plain))}` },
        { title: "Crear la clave de 256 bits", detail: "PBKDF2 mezcla contraseña y salt durante 100,000 iteraciones.", value: `salt ${bytesToBase64(salt)} · clave ${compact(bytesToHex(raw), 36)}` },
        { title: "Generar un IV irrepetible", detail: "El IV hace que el mismo mensaje produzca resultados distintos.", value: `IV de 96 bits · ${bytesToBase64(iv)}` },
        { title: "Cifrar y autenticar", detail: "AES-GCM transforma los bytes y añade control de integridad.", value: `${new Uint8Array(encrypted).length} bytes cifrados · ${compact(data)}` },
      ]);
    } catch { setError("No fue posible cifrar el mensaje."); }
    finally { setBusy(false); }
  }

  async function decryptMessage() {
    if (!cipherPackage || !password) { setError("Primero cifra un mensaje y conserva la contraseña."); return; }
    setBusy(true); setError(""); setOperation("Descifrado");
    try {
      const parsed = JSON.parse(cipherPackage) as { salt: string; iv: string; data: string };
      const salt = base64ToBytes(parsed.salt);
      const iv = base64ToBytes(parsed.iv);
      const encrypted = base64ToBytes(parsed.data);
      const { key, raw } = await deriveKey(password, salt);
      const plainBuffer = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, encrypted);
      const plainBytes = new Uint8Array(plainBuffer);
      const text = decoder.decode(plainBytes);
      setDecrypted(text);
      setSteps([
        { title: "Separar los datos del paquete", detail: "Se extraen salt, IV y texto cifrado. No son secretos; viajan junto al resultado.", value: `salt 16 bytes · IV 12 bytes · cifrado ${encrypted.length} bytes` },
        { title: "Reconstruir exactamente la clave", detail: "La misma contraseña y el salt almacenado pasan otra vez por PBKDF2.", value: `clave AES-256 recreada · ${compact(bytesToHex(raw), 38)}` },
        { title: "Validar y descifrar con AES-GCM", detail: "GCM revisa primero la autenticidad. Una contraseña o paquete incorrecto detiene el proceso.", value: "Etiqueta válida · descifrado autorizado" },
        { title: "Convertir los bytes a texto", detail: "Los bytes recuperados se interpretan como UTF-8 para mostrar el mensaje original.", value: `${plainBytes.length} bytes → “${text}”` },
      ]);
    } catch {
      setDecrypted("");
      setSteps([
        { title: "Separar los datos del paquete", detail: "Se intenta leer salt, IV y texto cifrado." },
        { title: "Reconstruir exactamente la clave", detail: "La contraseña suministrada produce una clave diferente si no coincide." },
        { title: "Validar y descifrar con AES-GCM", detail: "La autenticación GCM rechazó los datos.", value: "Proceso detenido: contraseña incorrecta o paquete alterado" },
        { title: "Convertir los bytes a texto", detail: "No se muestra ningún texto porque la validación falló." },
      ]);
      setError("Descifrado rechazado: la contraseña es incorrecta o el paquete fue alterado.");
    } finally { setBusy(false); }
  }

  return (
    <div>
      <ModuleHeader number="01" category="Cifrado simétrico" title="AES-256" description="La misma clave cifra y descifra. La demostración deriva una clave segura con PBKDF2 y usa AES-GCM para proteger también la integridad." />
      <div className="module-grid">
        <section className="work-panel">
          <div className="panel-title"><LockKeyhole /><strong>Prueba de cifrado y descifrado</strong></div>
          <div className="field-row">
            <FieldLabel hint={`${encoder.encode(message).length} bytes`}>Mensaje original</FieldLabel>
            <Textarea className="lab-textarea" value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <div className="field-row">
            <FieldLabel hint="La misma sirve para recuperar">Contraseña compartida</FieldLabel>
            <input className="lab-input" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="actions">
            <Button className="action-primary" onClick={encryptMessage} disabled={busy}><ArrowRight />Cifrar mensaje</Button>
            <Button className="action-secondary" onClick={decryptMessage} disabled={busy || !cipherPackage}><ArrowLeft />Descifrar paquete</Button>
          </div>
          <StatusMessage error={error} />
          {decrypted ? <ResultBox title="Texto descifrado / recuperado" value={decrypted} plain /> : null}
          {cipherPackage ? <ResultBox title="Paquete cifrado AES-256-GCM" value={cipherPackage} /> : null}
        </section>
        <ProcessPanel title={operation === "Descifrado" ? "Cómo se recuperó el texto" : "Cómo se cifró el mensaje"} operation={operation} steps={steps} />
      </div>
      <Facts sentence="AES usa una clave secreta para transformar y recuperar la información." protects="Confidencialidad e integridad." doesNot="No distribuye la clave por sí solo." useCase="Archivos, discos y respaldos." />
    </div>
  );
}

const rsaInitial: Step[] = [
  { title: "Crear un par de claves", detail: "La pública se comparte y la privada permanece bajo control del receptor." },
  { title: "Preparar con OAEP y SHA-256", detail: "El relleno incorpora aleatoriedad antes de la operación RSA." },
  { title: "Cifrar con la clave pública", detail: "Cualquiera puede proteger un mensaje dirigido al receptor." },
  { title: "Conservar la clave privada", detail: "Solo esa clave relacionada podrá recuperar la información." },
];

function RsaLab() {
  const [message, setMessage] = useState("Solo quien tenga la clave privada podrá leer esto.");
  const [keys, setKeys] = useState<CryptoKeyPair | null>(null);
  const [fingerprintValue, setFingerprintValue] = useState("");
  const [ciphertext, setCiphertext] = useState("");
  const [decrypted, setDecrypted] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [operation, setOperation] = useState("Cifrado");
  const [steps, setSteps] = useState<Step[]>(rsaInitial);

  async function generatePair() {
    return await crypto.subtle.generateKey(
      { name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
      true, ["encrypt", "decrypt"],
    ) as CryptoKeyPair;
  }

  async function createKeys() {
    setBusy(true); setError(""); setOperation("Generación");
    try {
      const pair = await generatePair();
      const fingerprint = await publicKeyFingerprint(pair.publicKey);
      setKeys(pair); setFingerprintValue(fingerprint); setCiphertext(""); setDecrypted("");
      setSteps([
        { title: "Solicitar claves RSA de 2048 bits", detail: "El navegador genera material criptográfico nuevo.", value: "Módulo de 2048 bits · exponente público 65537" },
        { title: "Separar las dos funciones", detail: "La clave pública queda habilitada para cifrar y la privada para descifrar.", value: "Pública: encrypt · Privada: decrypt" },
        { title: "Identificar la clave pública", detail: "Una huella SHA-256 permite reconocer el par sin mostrar toda la clave.", value: fingerprint },
        { title: "Proteger la clave privada", detail: "En esta demostración solo existe en la memoria temporal del navegador.", value: "No se transmite ni se publica" },
      ]);
    } catch { setError("No fue posible generar el par de claves."); }
    finally { setBusy(false); }
  }

  async function encryptRsa() {
    const byteLength = encoder.encode(message).length;
    if (!message.trim()) { setError("Escribe un mensaje antes de cifrar."); return; }
    if (byteLength > 190) { setError("RSA-2048 con OAEP/SHA-256 admite como máximo 190 bytes en esta prueba."); return; }
    setBusy(true); setError(""); setDecrypted(""); setOperation("Cifrado");
    try {
      let pair = keys;
      if (!pair) { pair = await generatePair(); setKeys(pair); }
      const fingerprint = await publicKeyFingerprint(pair.publicKey);
      setFingerprintValue(fingerprint);
      const encrypted = await crypto.subtle.encrypt({ name: "RSA-OAEP" }, pair.publicKey, encoder.encode(message));
      const encoded = bytesToBase64(new Uint8Array(encrypted));
      setCiphertext(encoded);
      setSteps([
        { title: "Seleccionar la clave pública", detail: "El emisor usa la parte del par que sí puede compartirse.", value: `Huella ${fingerprint}` },
        { title: "Preparar con OAEP y SHA-256", detail: "OAEP agrega aleatoriedad y estructura segura al mensaje.", value: `${byteLength} bytes de entrada` },
        { title: "Ejecutar RSA", detail: "La operación matemática se realiza con la clave pública.", value: `Resultado fijo de ${new Uint8Array(encrypted).length} bytes` },
        { title: "Codificar para transportarlo", detail: "Base64 convierte los bytes binarios en texto copiable.", value: compact(encoded) },
      ]);
    } catch { setError("No fue posible cifrar el mensaje."); }
    finally { setBusy(false); }
  }

  async function decryptRsa() {
    if (!keys || !ciphertext) { setError("Primero genera las claves y cifra un mensaje."); return; }
    setBusy(true); setError(""); setOperation("Descifrado");
    try {
      const encrypted = base64ToBytes(ciphertext);
      const plainBuffer = await crypto.subtle.decrypt({ name: "RSA-OAEP" }, keys.privateKey, encrypted);
      const plainBytes = new Uint8Array(plainBuffer);
      const text = decoder.decode(plainBytes);
      setDecrypted(text);
      setSteps([
        { title: "Recibir y decodificar el cifrado", detail: "Base64 vuelve a convertirse en los 256 bytes producidos por RSA.", value: `${encrypted.length} bytes recibidos` },
        { title: "Seleccionar la clave privada", detail: "No sirve la clave pública ni una privada de otro par.", value: "Clave privada relacionada encontrada en memoria" },
        { title: "Revertir RSA-OAEP", detail: "La clave privada resuelve la operación RSA y OAEP valida la estructura.", value: `${plainBytes.length} bytes originales recuperados` },
        { title: "Interpretar los bytes como UTF-8", detail: "El contenido binario recuperado vuelve a mostrarse como texto legible.", value: `“${text}”` },
      ]);
    } catch {
      setDecrypted("");
      setError("La clave privada actual no puede descifrar ese texto.");
    } finally { setBusy(false); }
  }

  return (
    <div>
      <ModuleHeader number="02" category="Cifrado asimétrico" title="RSA-2048" description="La clave pública cifra; la privada descifra. Así se evita compartir un secreto antes de iniciar la comunicación." />
      <div className="module-grid">
        <section className="work-panel">
          <div className="key-pair">
            <div className="key-card"><h4><FileKey2 />Clave pública</h4><p>Se puede compartir y sirve para cifrar.</p><code>{fingerprintValue || "Aún no generada"}</code></div>
            <div className="key-card"><h4><KeyRound />Clave privada</h4><p>Debe mantenerse secreta y sirve para descifrar.</p><code>{keys ? "Disponible únicamente en memoria" : "Aún no generada"}</code></div>
          </div>
          <Button className="action-secondary" onClick={createKeys} disabled={busy}><RefreshCw />Generar otro par</Button>
          <div className="field-row">
            <FieldLabel hint={`${encoder.encode(message).length}/190 bytes`}>Mensaje para el receptor</FieldLabel>
            <Textarea className="lab-textarea" value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <div className="actions">
            <Button className="action-primary" onClick={encryptRsa} disabled={busy}><ArrowRight />Cifrar con pública</Button>
            <Button className="action-secondary" onClick={decryptRsa} disabled={busy || !ciphertext}><ArrowLeft />Descifrar con privada</Button>
          </div>
          <StatusMessage error={error} />
          {decrypted ? <ResultBox title="Texto descifrado / recuperado" value={decrypted} plain /> : null}
          {ciphertext ? <ResultBox title="Texto cifrado RSA en Base64" value={ciphertext} /> : null}
        </section>
        <ProcessPanel title={operation === "Descifrado" ? "Cómo actuó la clave privada" : operation === "Generación" ? "Cómo nació el par de claves" : "Cómo actuó la clave pública"} operation={operation} steps={steps} />
      </div>
      <Facts sentence="La clave pública cierra el candado y la privada relacionada lo abre." protects="Confidencialidad sin clave compartida." doesNot="No cifra eficientemente archivos grandes." useCase="Intercambio de claves y mensajes breves." />
    </div>
  );
}

function HashLab() {
  const [message, setMessage] = useState("La integridad importa");
  const [algorithm, setAlgorithm] = useState<HashAlgorithm>("SHA-256");
  const [result, setResult] = useState("");
  const [changedResult, setChangedResult] = useState("");
  const [changedMessage, setChangedMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [steps, setSteps] = useState<Step[]>([
    { title: "Recibir cualquier cantidad de datos", detail: "La entrada se convierte a bytes antes del cálculo." },
    { title: "Completar y dividir en bloques", detail: "El algoritmo organiza la información en bloques fijos." },
    { title: "Mezclar durante varias rondas", detail: "Cada bit de entrada termina influyendo en la salida." },
    { title: "Emitir una huella fija", detail: "No existe una operación para recuperar el mensaje desde la huella." },
  ]);

  async function runHash() {
    setBusy(true);
    try {
      const altered = `${message}${message.endsWith("!") ? "." : "!"}`;
      const [originalHash, alteredHash] = await Promise.all([
        calculateHash(algorithm, message), calculateHash(algorithm, altered),
      ]);
      const bits = algorithm === "SHA-512" ? 512 : algorithm === "SHA-256" ? 256 : 128;
      const rounds = algorithm === "SHA-512" ? 80 : 64;
      const block = algorithm === "SHA-512" ? 1024 : 512;
      setResult(originalHash); setChangedResult(alteredHash); setChangedMessage(altered);
      setSteps([
        { title: "Recibir cualquier cantidad de datos", detail: "La entrada se convierte a bytes antes del cálculo.", value: `${encoder.encode(message).length} bytes · “${message || "(vacío)"}”` },
        { title: "Completar y dividir en bloques", detail: "El algoritmo agrega padding y trabaja por bloques.", value: `Bloques de ${block} bits` },
        { title: "Mezclar durante varias rondas", detail: "Operaciones binarias propagan cada pequeño cambio.", value: `${rounds} rondas por bloque` },
        { title: "Emitir una huella fija", detail: "La longitud final depende del algoritmo, no del mensaje.", value: `${bits} bits · ${originalHash}` },
      ]);
    } finally { setBusy(false); }
  }

  const difference = useMemo(
    () => !result || !changedResult ? 0 : result.split("").filter((char, i) => char !== changedResult[i]).length,
    [result, changedResult],
  );

  return (
    <div>
      <ModuleHeader number="03" category="Función unidireccional" title="Funciones hash" description="SHA-256, SHA-512 y MD5 producen una huella de longitud fija. Un hash no cifra y no se puede descifrar." />
      <div className="module-grid">
        <section className="work-panel">
          <div className="panel-title"><Fingerprint /><strong>Calculadora de huellas</strong></div>
          <div className="choice-row">
            {(["SHA-256", "SHA-512", "MD5"] as HashAlgorithm[]).map((item) => (
              <Button key={item} onClick={() => { setAlgorithm(item); setResult(""); setChangedResult(""); }} className={`choice ${algorithm === item ? "choice--active" : ""}`}>{item}</Button>
            ))}
          </div>
          <FieldLabel hint="Misma entrada = misma huella">Mensaje de entrada</FieldLabel>
          <Textarea className="lab-textarea" value={message} onChange={(e) => setMessage(e.target.value)} />
          <div className="actions"><Button className="action-primary" onClick={runHash} disabled={busy}><Fingerprint />Calcular {algorithm}</Button></div>
          {algorithm === "MD5" ? <StatusMessage error="MD5 tiene colisiones conocidas. Solo se incluye para comparación académica." /> : null}
          {result ? <ResultBox title={`Huella ${algorithm}`} value={result} /> : null}
          {changedResult ? (
            <div className="avalanche">
              <strong>Efecto avalancha: {difference} de {result.length} dígitos cambiaron.</strong>
              <div>Solo agregamos un carácter al mensaje: “{changedMessage}”.</div>
              <code>{changedResult}</code>
            </div>
          ) : null}
        </section>
        <ProcessPanel title="Cómo se calculó la huella" operation={algorithm} steps={steps} />
      </div>
      <Facts sentence="Un hash compara integridad; no es texto cifrado y no tiene descifrado." protects="Integridad y detección de cambios." doesNot="No oculta ni recupera información." useCase="Contraseñas, descargas y blockchain." />
    </div>
  );
}

function SignatureLab() {
  const [message, setMessage] = useState("Apruebo el contenido de este documento.");
  const [verifyMessage, setVerifyMessage] = useState("Apruebo el contenido de este documento.");
  const [keys, setKeys] = useState<CryptoKeyPair | null>(null);
  const [fingerprintValue, setFingerprintValue] = useState("");
  const [signature, setSignature] = useState("");
  const [verification, setVerification] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [operation, setOperation] = useState("Firma");
  const [steps, setSteps] = useState<Step[]>([
    { title: "Calcular SHA-256 del mensaje", detail: "La huella representa exactamente el contenido firmado." },
    { title: "Firmar con la clave privada", detail: "RSA-PSS crea una evidencia que solo el autor puede producir." },
    { title: "Enviar mensaje y firma", detail: "El contenido sigue visible; la firma viaja como evidencia aparte." },
    { title: "Conservar la clave pública", detail: "Cualquier receptor puede usarla después para verificar." },
  ]);

  async function createSigningKeys() {
    const pair = await crypto.subtle.generateKey(
      { name: "RSA-PSS", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
      true, ["sign", "verify"],
    ) as CryptoKeyPair;
    const fingerprint = await publicKeyFingerprint(pair.publicKey);
    setKeys(pair); setFingerprintValue(fingerprint);
    return { pair, fingerprint };
  }

  async function signMessage() {
    if (!message.trim()) { setError("Escribe el mensaje que deseas firmar."); return; }
    setBusy(true); setError(""); setVerification(null); setOperation("Firma");
    try {
      let pair = keys, fingerprint = fingerprintValue;
      if (!pair) {
        const created = await createSigningKeys();
        pair = created.pair; fingerprint = created.fingerprint;
      }
      const digest = await calculateHash("SHA-256", message);
      const signed = await crypto.subtle.sign(
        { name: "RSA-PSS", saltLength: 32 }, pair.privateKey, encoder.encode(message),
      );
      const encoded = bytesToBase64(new Uint8Array(signed));
      setSignature(encoded); setVerifyMessage(message);
      setSteps([
        { title: "Calcular SHA-256 del mensaje", detail: "Una modificación mínima produciría una huella diferente.", value: digest },
        { title: "Firmar con la clave privada", detail: "RSA-PSS usa la identidad criptográfica del autor.", value: `Firma de ${new Uint8Array(signed).length} bytes` },
        { title: "Enviar mensaje y firma", detail: "No se cifra el contenido: se adjunta la firma codificada en Base64.", value: compact(encoded) },
        { title: "Publicar la clave de verificación", detail: "La privada no sale del autor; la pública identifica al firmante.", value: `Huella pública ${fingerprint}` },
      ]);
    } catch { setError("No fue posible firmar el mensaje."); }
    finally { setBusy(false); }
  }

  async function verifySignature() {
    if (!keys || !signature) { setError("Primero firma un mensaje."); return; }
    setBusy(true); setError(""); setOperation("Verificación");
    try {
      const receivedHash = await calculateHash("SHA-256", verifyMessage);
      const valid = await crypto.subtle.verify(
        { name: "RSA-PSS", saltLength: 32 },
        keys.publicKey, base64ToBytes(signature), encoder.encode(verifyMessage),
      );
      setVerification(valid);
      setSteps([
        { title: "Separar mensaje y firma", detail: "El receptor recibe ambos elementos; el mensaje permanece legible.", value: `${encoder.encode(verifyMessage).length} bytes de mensaje · 256 bytes de firma` },
        { title: "Calcular el hash recibido", detail: "SHA-256 resume exactamente el texto que llegó.", value: receivedHash },
        { title: "Comprobar con la clave pública", detail: "RSA-PSS verifica si la firma fue creada por la privada relacionada.", value: `Clave pública ${fingerprintValue}` },
        { title: "Emitir el resultado", detail: valid ? "La identidad y el contenido coinciden." : "Algo cambió: el mensaje, la firma o la clave no coincide.", value: valid ? "FIRMA VÁLIDA" : "FIRMA INVÁLIDA" },
      ]);
    } catch { setVerification(false); setError("La firma no tiene un formato válido."); }
    finally { setBusy(false); }
  }

  function alterMessage() {
    setVerifyMessage((current) => `${current}${current.endsWith("!") ? "." : "!"}`);
    setVerification(null);
  }

  return (
    <div>
      <ModuleHeader number="04" category="Autenticidad e integridad" title="Firma digital" description="La clave privada firma y la pública verifica. El mensaje no se oculta: se demuestra autoría y ausencia de cambios." />
      <div className="module-grid">
        <section className="work-panel">
          <div className="panel-title"><BadgeCheck /><strong>Firmar y comprobar un mensaje</strong></div>
          <div className="key-pair">
            <div className="key-card"><h4><BadgeCheck />Firmante</h4><p>La firma se produce con su clave privada.</p><code>{fingerprintValue || "Identidad pendiente"}</code></div>
            <div className="key-card"><h4><ShieldCheck />Verificador</h4><p>Solo necesita la clave pública y la firma.</p><code>RSA-PSS · SHA-256</code></div>
          </div>
          <FieldLabel>Mensaje que firma el autor</FieldLabel>
          <Textarea className="lab-textarea" value={message} onChange={(e) => { setMessage(e.target.value); setVerification(null); }} />
          <div className="actions"><Button className="action-primary" onClick={signMessage} disabled={busy}><BadgeCheck />Firmar con privada</Button></div>
          {signature ? <ResultBox title="Firma digital en Base64" value={signature} /> : null}
          <div className="field-row">
            <FieldLabel hint="Puedes cambiarlo antes de verificar">Mensaje recibido</FieldLabel>
            <Textarea className="lab-textarea" value={verifyMessage} onChange={(e) => { setVerifyMessage(e.target.value); setVerification(null); }} />
          </div>
          <div className="actions">
            <Button className="action-primary" onClick={verifySignature} disabled={busy || !signature}><ScanSearch />Verificar con pública</Button>
            <Button className="action-secondary" onClick={alterMessage} disabled={!signature}><Binary />Alterar un carácter</Button>
          </div>
          <StatusMessage
            error={error || (verification === false ? "Firma inválida: el mensaje fue alterado o no pertenece al firmante." : "")}
            success={verification === true ? "Firma válida: autor y contenido comprobados." : undefined}
          />
        </section>
        <ProcessPanel title={operation === "Verificación" ? "Cómo se verificó la firma" : "Cómo se creó la firma"} operation={operation} steps={steps} />
      </div>
      <Facts sentence="La firma prueba quién aprobó el mensaje y que este no cambió." protects="Autenticidad e integridad." doesNot="No vuelve secreto el contenido." useCase="Contratos, certificados y software." />
    </div>
  );
}

function caesarTransform(text: string, shift: number) {
  return Array.from(text).map((char) => {
    const code = char.charCodeAt(0);
    if (code >= 65 && code <= 90) return String.fromCharCode(((code - 65 + shift + 26) % 26) + 65);
    if (code >= 97 && code <= 122) return String.fromCharCode(((code - 97 + shift + 26) % 26) + 97);
    return char;
  }).join("");
}

function CaesarLab() {
  const [message, setMessage] = useState("SEGURIDAD EN CAPAS");
  const [shift, setShift] = useState(3);
  const [result, setResult] = useState("");
  const [processedInput, setProcessedInput] = useState("");
  const [mode, setMode] = useState<"encrypt" | "decrypt">("encrypt");
  const [showBruteForce, setShowBruteForce] = useState(false);

  const source = processedInput || message;
  const mapping = useMemo(
    () => Array.from(source).filter((char) => /[a-z]/i.test(char)).slice(0, 14)
      .map((char) => [char, caesarTransform(char, mode === "encrypt" ? shift : -shift)]),
    [source, mode, shift],
  );
  const steps: Step[] = mode === "encrypt" ? [
    { title: "Elegir el desplazamiento", detail: "La clave n indica cuántas posiciones avanzar.", value: `n = ${shift}` },
    { title: "Convertir letras a posiciones", detail: "A=0, B=1... Z=25. Espacios y signos se conservan.", value: mapping.slice(0, 5).map(([from]) => `${from.toUpperCase()}=${from.toUpperCase().charCodeAt(0) - 65}`).join(" · ") || "Sin letras A-Z" },
    { title: "Sumar n y aplicar módulo 26", detail: "E(x) = (x + n) mod 26 permite volver a A después de Z.", value: mapping.slice(0, 7).map(([from, to]) => `${from}→${to}`).join("  ") || "Sin letras A-Z" },
    { title: "Reconstruir el texto cifrado", detail: "Las nuevas posiciones vuelven a convertirse en letras.", value: result || "Pendiente" },
  ] : [
    { title: "Tomar el texto cifrado y la clave", detail: "Se necesita el mismo desplazamiento utilizado al cifrar.", value: `n = ${shift} · entrada “${source}”` },
    { title: "Convertir letras a posiciones", detail: "Cada símbolo cifrado vuelve a su número entre 0 y 25.", value: mapping.slice(0, 5).map(([from]) => `${from.toUpperCase()}=${from.toUpperCase().charCodeAt(0) - 65}`).join(" · ") || "Sin letras A-Z" },
    { title: "Restar n y aplicar módulo 26", detail: "D(x) = (x − n) mod 26 revierte el desplazamiento.", value: mapping.slice(0, 7).map(([from, to]) => `${from}→${to}`).join("  ") || "Sin letras A-Z" },
    { title: "Reconstruir el mensaje original", detail: "Las posiciones recuperadas vuelven a convertirse en letras legibles.", value: result || "Pendiente" },
  ];

  function execute(nextMode: "encrypt" | "decrypt") {
    const input = nextMode === "decrypt" && mode === "encrypt" && result ? result : message;
    setProcessedInput(input);
    setMode(nextMode);
    setResult(caesarTransform(input, nextMode === "encrypt" ? shift : -shift));
    setShowBruteForce(false);
  }

  return (
    <div>
      <ModuleHeader number="05" category="Cifrado clásico" title="Cifrado César" description="Cada letra se desplaza una cantidad fija. Sirve para entender sustitución, pero solo existen 25 claves posibles." />
      <div className="module-grid">
        <section className="work-panel">
          <div className="panel-title"><RotateCcw /><strong>Sustitución letra por letra</strong></div>
          <FieldLabel hint="Alfabeto A–Z">Mensaje o texto cifrado</FieldLabel>
          <Textarea className="lab-textarea" value={message} onChange={(e) => { setMessage(e.target.value); setResult(""); setProcessedInput(""); }} />
          <div className="slider-box">
            <div className="slider-box__top"><strong>Desplazamiento</strong><span className="slider-box__value">{shift}</span></div>
            <Slider min={1} max={25} step={1} value={[shift]} onValueChange={(values) => { setShift(values[0]); setResult(""); setProcessedInput(""); }} />
          </div>
          <div className="actions">
            <Button className="action-primary" onClick={() => execute("encrypt")}><ArrowRight />Cifrar</Button>
            <Button className="action-secondary" onClick={() => execute("decrypt")}><ArrowLeft />Descifrar</Button>
            <Button className="action-quiet" onClick={() => setShowBruteForce((current) => !current)}><ScanSearch />{showBruteForce ? "Ocultar ataque" : "Probar fuerza bruta"}</Button>
          </div>
          {result ? <ResultBox title={mode === "encrypt" ? "Texto cifrado" : "Texto descifrado / recuperado"} value={result} plain={mode === "decrypt"} /> : null}
          <div className="mapping">{mapping.map(([from, to], i) => <span key={`${from}-${i}`}><b>{from}</b> → {to}</span>)}</div>
          {showBruteForce ? (
            <div className="brute-force">
              <p className="eyebrow">Las 25 claves posibles</p>
              <div className="brute-force__grid">
                {Array.from({ length: 25 }, (_, i) => i + 1).map((candidate) => (
                  <div className="brute-force__row" key={candidate}><b>{candidate.toString().padStart(2, "0")}</b><span>{caesarTransform(result || message, -candidate)}</span></div>
                ))}
              </div>
            </div>
          ) : null}
        </section>
        <ProcessPanel title={mode === "decrypt" ? "Cómo se recuperó el texto" : "Cómo se desplazaron las letras"} operation={mode === "decrypt" ? "Descifrado" : "Cifrado"} steps={steps} />
      </div>
      <Facts sentence="César mueve cada letra una distancia fija y revierte restando esa distancia." protects="Ocultamiento histórico básico." doesNot="No resiste fuerza bruta." useCase="Historia y aprendizaje de sustitución." />
    </div>
  );
}

const tabItems = [
  { value: "aes", label: "AES-256", icon: LockKeyhole },
  { value: "rsa", label: "RSA", icon: KeyRound },
  { value: "hash", label: "Hash", icon: Fingerprint },
  { value: "signature", label: "Firma digital", icon: BadgeCheck },
  { value: "caesar", label: "César", icon: RotateCcw },
];

export function CryptoLab() {
  const [activeTab, setActiveTab] = useState("aes");
  return (
    <main>
      <header className="site-top">
        <div className="site-top__inner">
          <div className="brand">
            <span className="brand__mark"><FlaskConical /></span>
            <div><div className="brand__name">Laboratorio de Cifrado</div><div className="brand__course">Gestión de seguridad en sistemas informáticos</div></div>
          </div>
          <div className="local-note">Procesamiento local y privado</div>
        </div>
      </header>
      <div className="workspace">
        <section className="intro">
          <div><span className="intro__kicker">Demostración interactiva / cinco métodos</span><h1>Criptografía, <em>sin cajas negras.</em></h1></div>
          <p className="intro__summary">Ejecuta cada operación y usa el panel derecho para explicar exactamente qué ocurre al cifrar, descifrar, calcular una huella o verificar una firma.</p>
        </section>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="tabs-scroll">
            <TabsList className="method-tabs" aria-label="Métodos criptográficos">
              {tabItems.map((item, index) => {
                const Icon = item.icon;
                return <TabsTrigger key={item.value} value={item.value} className="method-tab"><span className="method-tab__number">{String(index + 1).padStart(2, "0")}</span><Icon />{item.label}</TabsTrigger>;
              })}
            </TabsList>
          </div>
          <TabsContent value="aes"><AesLab /></TabsContent>
          <TabsContent value="rsa"><RsaLab /></TabsContent>
          <TabsContent value="hash"><HashLab /></TabsContent>
          <TabsContent value="signature"><SignatureLab /></TabsContent>
          <TabsContent value="caesar"><CaesarLab /></TabsContent>
        </Tabs>
        <footer className="footer">
          <span><strong>Nota académica:</strong> MD5 y César no deben proteger información real.</span>
          <span>Web Crypto API · ejecución en el navegador</span>
        </footer>
      </div>
    </main>
  );
}
