using System.Security.Cryptography;
using System.Text;

namespace Encriptador.Services
{
    /// <summary>
    /// Contiene la lógica de los 5 métodos de cifrado implementados en el proyecto:
    /// 1. AES-256 (cifrado simétrico)
    /// 2. RSA (cifrado asimétrico)
    /// 3. SHA-256 / SHA-512 / MD5 (funciones hash)
    /// 4. Firma digital con RSA (firma y verificación)
    /// 5. Cifrado César (cifrado clásico por sustitución)
    /// </summary>
    public class CryptoService
    {
        // =========================================================
        // 1. AES-256 - CIFRADO SIMÉTRICO
        // =========================================================
        // AES (Advanced Encryption Standard) usa la MISMA clave para
        // cifrar y descifrar. La clave del usuario se deriva a una
        // llave de 256 bits mediante PBKDF2 (derivación segura de
        // claves a partir de una contraseña), y se genera un IV
        // (vector de inicialización) aleatorio por cada operación.
        public string AesEncrypt(string plainText, string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);
            using var key = new Rfc2898DeriveBytes(password, salt, 100_000, HashAlgorithmName.SHA256);
            using var aes = Aes.Create();
            aes.Key = key.GetBytes(32); // AES-256
            aes.GenerateIV();           // IV aleatorio de 16 bytes

            using var encryptor = aes.CreateEncryptor();
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            // Empaquetamos salt + IV + texto cifrado para poder descifrar después
            byte[] result = new byte[salt.Length + aes.IV.Length + cipherBytes.Length];
            Buffer.BlockCopy(salt, 0, result, 0, salt.Length);
            Buffer.BlockCopy(aes.IV, 0, result, salt.Length, aes.IV.Length);
            Buffer.BlockCopy(cipherBytes, 0, result, salt.Length + aes.IV.Length, cipherBytes.Length);

            return Convert.ToBase64String(result);
        }

        public string AesDecrypt(string cipherTextBase64, string password)
        {
            byte[] fullData = Convert.FromBase64String(cipherTextBase64);

            byte[] salt = fullData[..16];
            byte[] iv = fullData[16..32];
            byte[] cipherBytes = fullData[32..];

            using var key = new Rfc2898DeriveBytes(password, salt, 100_000, HashAlgorithmName.SHA256);
            using var aes = Aes.Create();
            aes.Key = key.GetBytes(32);
            aes.IV = iv;

            using var decryptor = aes.CreateDecryptor();
            byte[] plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            return Encoding.UTF8.GetString(plainBytes);
        }

        // =========================================================
        // 2. RSA - CIFRADO ASIMÉTRICO
        // =========================================================
        // RSA usa un PAR de claves: la pública (para cifrar) y la
        // privada (para descifrar). Solo quien tiene la clave privada
        // puede recuperar el mensaje original.
        public (string publicKey, string privateKey) RsaGenerateKeys()
        {
            using var rsa = RSA.Create(2048);
            string publicKey = Convert.ToBase64String(rsa.ExportRSAPublicKey());
            string privateKey = Convert.ToBase64String(rsa.ExportRSAPrivateKey());
            return (publicKey, privateKey);
        }

        public string RsaEncrypt(string plainText, string publicKeyBase64)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPublicKey(Convert.FromBase64String(publicKeyBase64), out _);
            byte[] data = Encoding.UTF8.GetBytes(plainText);
            byte[] encrypted = rsa.Encrypt(data, RSAEncryptionPadding.OaepSHA256);
            return Convert.ToBase64String(encrypted);
        }

        public string RsaDecrypt(string cipherTextBase64, string privateKeyBase64)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPrivateKey(Convert.FromBase64String(privateKeyBase64), out _);
            byte[] data = Convert.FromBase64String(cipherTextBase64);
            byte[] decrypted = rsa.Decrypt(data, RSAEncryptionPadding.OaepSHA256);
            return Encoding.UTF8.GetString(decrypted);
        }

        // =========================================================
        // 3. FUNCIONES HASH (SHA-256 / SHA-512 / MD5)
        // =========================================================
        // Un hash es una "huella digital" de longitud fija que se
        // obtiene a partir de un texto. NO es reversible: no existe
        // una operación de "deshash". Se usa para verificar
        // integridad (que el archivo/mensaje no fue alterado).
        public string ComputeHash(string text, string algorithm)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            byte[] hashBytes = algorithm switch
            {
                "SHA512" => SHA512.HashData(bytes),
                "MD5" => MD5.HashData(bytes),
                _ => SHA256.HashData(bytes),
            };
            return Convert.ToHexString(hashBytes).ToLowerInvariant();
        }

        // =========================================================
        // 4. FIRMA DIGITAL (RSA + SHA-256)
        // =========================================================
        // La firma digital garantiza AUTENTICIDAD e INTEGRIDAD:
        // - Se firma con la clave PRIVADA del emisor.
        // - Cualquiera puede verificar con la clave PÚBLICA del emisor.
        // Si el mensaje cambia una sola letra, la verificación falla.
        public string Sign(string text, string privateKeyBase64)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPrivateKey(Convert.FromBase64String(privateKeyBase64), out _);
            byte[] data = Encoding.UTF8.GetBytes(text);
            byte[] signature = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            return Convert.ToBase64String(signature);
        }

        public bool Verify(string text, string signatureBase64, string publicKeyBase64)
        {
            using var rsa = RSA.Create();
            rsa.ImportRSAPublicKey(Convert.FromBase64String(publicKeyBase64), out _);
            byte[] data = Encoding.UTF8.GetBytes(text);
            byte[] signature = Convert.FromBase64String(signatureBase64);
            return rsa.VerifyData(data, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }

        // =========================================================
        // 5. CIFRADO CÉSAR - CIFRADO CLÁSICO POR SUSTITUCIÓN
        // =========================================================
        // Cada letra se desplaza "n" posiciones en el alfabeto.
        // Es simétrico y didáctico, pero NO seguro para uso real
        // (se rompe fácilmente por fuerza bruta o análisis de
        // frecuencia). Se incluye como referencia histórica.
        public string CaesarEncrypt(string text, int shift)
        {
            return ShiftText(text, shift);
        }

        public string CaesarDecrypt(string text, int shift)
        {
            return ShiftText(text, -shift);
        }

        private string ShiftText(string text, int shift)
        {
            var result = new StringBuilder();
            shift = ((shift % 26) + 26) % 26;

            foreach (char c in text)
            {
                if (char.IsUpper(c))
                {
                    result.Append((char)(((c - 'A' + shift) % 26) + 'A'));
                }
                else if (char.IsLower(c))
                {
                    result.Append((char)(((c - 'a' + shift) % 26) + 'a'));
                }
                else
                {
                    result.Append(c); // números, espacios y signos no se modifican
                }
            }
            return result.ToString();
        }
    }
}
