using Encriptador.Models;
using Encriptador.Services;
using Microsoft.AspNetCore.Mvc;

namespace Encriptador.Controllers
{
    public class CryptoController : Controller
    {
        private readonly CryptoService _crypto;

        public CryptoController(CryptoService crypto)
        {
            _crypto = crypto;
        }

        public IActionResult Index()
        {
            return View();
        }

        // ---------------- AES ----------------
        [HttpGet]
        public IActionResult Aes() => View(new AesViewModel());

        [HttpPost]
        public IActionResult Aes(AesViewModel model)
        {
            try
            {
                if (string.IsNullOrEmpty(model.Texto) || string.IsNullOrEmpty(model.Clave))
                {
                    model.Error = "Debes ingresar el texto y la clave.";
                    return View(model);
                }

                model.Resultado = model.Accion == "Descifrar"
                    ? _crypto.AesDecrypt(model.Texto, model.Clave)
                    : _crypto.AesEncrypt(model.Texto, model.Clave);
            }
            catch (Exception)
            {
                model.Error = "No se pudo procesar el texto. Verifica que el texto cifrado y la clave sean correctos.";
            }
            return View(model);
        }

        // ---------------- RSA ----------------
        [HttpGet]
        public IActionResult Rsa() => View(new RsaViewModel());

        [HttpPost]
        public IActionResult Rsa(RsaViewModel model)
        {
            try
            {
                switch (model.Accion)
                {
                    case "GenerarClaves":
                        var (pub, priv) = _crypto.RsaGenerateKeys();
                        model.ClavePublica = pub;
                        model.ClavePrivada = priv;
                        break;

                    case "Descifrar":
                        model.Resultado = _crypto.RsaDecrypt(model.Texto!, model.ClavePrivada!);
                        break;

                    default: // Cifrar
                        model.Resultado = _crypto.RsaEncrypt(model.Texto!, model.ClavePublica!);
                        break;
                }
            }
            catch (Exception)
            {
                model.Error = "Ocurrió un error. Verifica el texto y las claves proporcionadas.";
            }
            return View(model);
        }

        // ---------------- HASH ----------------
        [HttpGet]
        public IActionResult Hash() => View(new HashViewModel { Algoritmo = "SHA256" });

        [HttpPost]
        public IActionResult Hash(HashViewModel model)
        {
            if (!string.IsNullOrEmpty(model.Texto))
            {
                model.Resultado = _crypto.ComputeHash(model.Texto, model.Algoritmo ?? "SHA256");
            }

            if (!string.IsNullOrEmpty(model.TextoVerificar) && !string.IsNullOrEmpty(model.HashComparar))
            {
                string calculado = _crypto.ComputeHash(model.TextoVerificar, model.Algoritmo ?? "SHA256");
                model.Coincide = calculado.Equals(model.HashComparar.Trim(), StringComparison.OrdinalIgnoreCase);
            }

            return View(model);
        }

        // ---------------- FIRMA DIGITAL ----------------
        [HttpGet]
        public IActionResult Signature() => View(new SignatureViewModel());

        [HttpPost]
        public IActionResult Signature(SignatureViewModel model)
        {
            try
            {
                switch (model.Accion)
                {
                    case "GenerarClaves":
                        var (pub, priv) = _crypto.RsaGenerateKeys();
                        model.ClavePublica = pub;
                        model.ClavePrivada = priv;
                        break;

                    case "Verificar":
                        model.EsValida = _crypto.Verify(
                            model.TextoVerificar ?? "",
                            model.FirmaVerificar ?? "",
                            model.ClavePublicaVerificar ?? "");
                        break;

                    default: // Firmar
                        model.Firma = _crypto.Sign(model.Texto ?? "", model.ClavePrivada ?? "");
                        break;
                }
            }
            catch (Exception)
            {
                model.Error = "Ocurrió un error. Verifica el texto, la firma y las claves proporcionadas.";
            }
            return View(model);
        }

        // ---------------- CÉSAR ----------------
        [HttpGet]
        public IActionResult Caesar() => View(new CaesarViewModel());

        [HttpPost]
        public IActionResult Caesar(CaesarViewModel model)
        {
            if (!string.IsNullOrEmpty(model.Texto))
            {
                model.Resultado = model.Accion == "Descifrar"
                    ? _crypto.CaesarDecrypt(model.Texto, model.Desplazamiento)
                    : _crypto.CaesarEncrypt(model.Texto, model.Desplazamiento);
            }
            return View(model);
        }
    }
}
