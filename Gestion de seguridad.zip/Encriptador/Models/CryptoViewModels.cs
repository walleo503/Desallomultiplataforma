namespace Encriptador.Models
{
    // ---------- AES (Cifrado Simétrico) ----------
    public class AesViewModel
    {
        public string? Texto { get; set; }
        public string? Clave { get; set; }
        public string? Resultado { get; set; }
        public string? Accion { get; set; } // "Cifrar" | "Descifrar"
        public string? Error { get; set; }
    }

    // ---------- RSA (Cifrado Asimétrico) ----------
    public class RsaViewModel
    {
        public string? Texto { get; set; }
        public string? Resultado { get; set; }
        public string? Accion { get; set; } // "GenerarClaves" | "Cifrar" | "Descifrar"
        public string? ClavePublica { get; set; }
        public string? ClavePrivada { get; set; }
        public string? Error { get; set; }
    }

    // ---------- SHA-256 / SHA-512 (Hash) ----------
    public class HashViewModel
    {
        public string? Texto { get; set; }
        public string? Algoritmo { get; set; } // "SHA256" | "SHA512" | "MD5"
        public string? Resultado { get; set; }
        public string? TextoVerificar { get; set; }
        public string? HashComparar { get; set; }
        public bool? Coincide { get; set; }
    }

    // ---------- Firma Digital (RSA Sign/Verify) ----------
    public class SignatureViewModel
    {
        public string? Texto { get; set; }
        public string? Accion { get; set; } // "GenerarClaves" | "Firmar" | "Verificar"
        public string? ClavePublica { get; set; }
        public string? ClavePrivada { get; set; }
        public string? Firma { get; set; }
        public string? FirmaVerificar { get; set; }
        public string? ClavePublicaVerificar { get; set; }
        public string? TextoVerificar { get; set; }
        public bool? EsValida { get; set; }
        public string? Error { get; set; }
    }

    // ---------- César (Cifrado clásico) ----------
    public class CaesarViewModel
    {
        public string? Texto { get; set; }
        public int Desplazamiento { get; set; } = 3;
        public string? Resultado { get; set; }
        public string? Accion { get; set; } // "Cifrar" | "Descifrar"
    }
}
